export type ToolCategory = "pdf" | "word" | "image";

export type ToolStatus = "live" | "needs-integration";

export type ToolOption = {
  key: string;
  label: string;
  type: "select" | "text" | "number";
  options?: { value: string; label: string }[];
  placeholder?: string;
  help?: string;
  defaultValue?: string;
};

export type Tool = {
  slug: string;
  name: string;
  h1: string;
  seoTitle: string;
  seoDescription: string;
  short: string;
  description: string;
  icon: string;
  accent: string;
  categories: ToolCategory[];
  accept: string;
  multiple: boolean;
  status: ToolStatus;
  statusNote?: string;
  outputHint: string;
  options?: ToolOption[];
  steps: string[];
  faq: { q: string; a: string }[];
  related: string[];
  popular?: boolean;
};

export const TOOLS: Tool[] = [
  {
    slug: "word-to-pdf",
    name: "Word vers PDF",
    h1: "Convertir Word en PDF gratuitement en ligne",
    seoTitle: "Convertir Word en PDF gratuitement en ligne | DocuConvert",
    seoDescription:
      "Convertissez vos fichiers Word (.docx) en PDF en quelques secondes. Outil gratuit, en ligne, sans installation et sécurisé.",
    short: "Transformez vos documents .doc et .docx en PDF prêts à partager.",
    description:
      "Notre convertisseur Word vers PDF transforme vos documents .docx en fichiers PDF paginés, lisibles sur tous les appareils. Le texte, les titres et les listes sont conservés, et la mise en page est normalisée au format A4.",
    icon: "word",
    accent: "from-blue-500 to-indigo-600",
    categories: ["word", "pdf"],
    accept: ".doc,.docx",
    multiple: false,
    status: "live",
    outputHint: "Fichier PDF (.pdf)",
    steps: [
      "Déposez votre fichier Word dans la zone de téléchargement ou cliquez sur « Choisir un fichier ».",
      "Vérifiez le nom et la taille du document sélectionné.",
      "Cliquez sur « Convertir en PDF » et patientez quelques secondes.",
      "Téléchargez votre PDF. Le fichier temporaire est supprimé automatiquement après la période de conservation.",
    ],
    faq: [
      {
        q: "La conversion Word vers PDF est-elle gratuite ?",
        a: "Oui. Les comptes gratuits disposent d'un quota quotidien de conversions et d'une taille de fichier limitée. Les offres Premium augmentent ces limites.",
      },
      {
        q: "Mes fichiers sont-ils conservés ?",
        a: "Les fichiers envoyés sont traités puis supprimés automatiquement à l'expiration du délai de conservation (2 heures par défaut).",
      },
      {
        q: "Quels formats Word sont acceptés ?",
        a: "Le format .docx est pris en charge nativement. Les anciens fichiers .doc binaires doivent être enregistrés en .docx avant conversion.",
      },
      {
        q: "La mise en page est-elle conservée ?",
        a: "Le texte, la hiérarchie des titres et les listes sont conservés. Les mises en page complexes (colonnes, en-têtes, images flottantes) sont simplifiées.",
      },
    ],
    related: ["pdf-to-word", "merge-pdf", "compress-pdf"],
    popular: true,
  },
  {
    slug: "pdf-to-word",
    name: "PDF vers Word",
    h1: "Convertir un PDF en Word (.docx) en ligne",
    seoTitle: "Convertir PDF en Word (.docx) gratuitement | DocuConvert",
    seoDescription:
      "Convertissez un PDF en document Word modifiable (.docx) directement depuis votre navigateur. Rapide, gratuit et sécurisé.",
    short: "Récupérez un document Word modifiable à partir d'un PDF.",
    description:
      "Notre convertisseur extrait le texte de votre PDF et génère un document Word (.docx) modifiable dans Microsoft Word, LibreOffice ou Google Docs. Idéal pour réutiliser un contenu sans tout retaper.",
    icon: "pdf",
    accent: "from-indigo-500 to-violet-600",
    categories: ["pdf", "word"],
    accept: ".pdf",
    multiple: false,
    status: "live",
    outputHint: "Document Word (.docx)",
    steps: [
      "Sélectionnez le PDF à convertir.",
      "Lancez la conversion « PDF vers Word ».",
      "Téléchargez le fichier .docx généré.",
      "Ouvrez et modifiez librement le document dans votre traitement de texte.",
    ],
    faq: [
      {
        q: "Les PDF scannés fonctionnent-ils ?",
        a: "Un PDF scanné ne contient pas de couche texte : la reconnaissance optique (OCR) est nécessaire. Elle n'est pas activée par défaut, l'outil vous prévient si aucun texte n'est détecté.",
      },
      {
        q: "Les images sont-elles récupérées ?",
        a: "La conversion actuelle se concentre sur le texte et la structure des paragraphes. Les images ne sont pas réinsérées dans le document Word.",
      },
      {
        q: "Puis-je convertir un PDF protégé par mot de passe ?",
        a: "Non. Retirez d'abord la protection depuis votre lecteur PDF, puis relancez la conversion.",
      },
    ],
    related: ["word-to-pdf", "split-pdf", "compress-pdf"],
    popular: true,
  },
  {
    slug: "jpg-to-pdf",
    name: "JPG vers PDF",
    h1: "Convertir des images JPG, PNG ou WEBP en PDF",
    seoTitle: "Convertir JPG en PDF en ligne gratuitement | DocuConvert",
    seoDescription:
      "Rassemblez vos images JPG, PNG et WEBP dans un seul fichier PDF. Outil en ligne gratuit, rapide et sans filigrane.",
    short: "Assemblez plusieurs images en un seul PDF propre.",
    description:
      "Déposez vos photos ou captures d'écran : chaque image devient une page PDF, centrée et redimensionnée automatiquement. Parfait pour envoyer des justificatifs ou archiver des documents photographiés.",
    icon: "image",
    accent: "from-sky-500 to-blue-600",
    categories: ["image", "pdf"],
    accept: ".jpg,.jpeg,.png,.webp",
    multiple: true,
    status: "live",
    outputHint: "Fichier PDF (.pdf)",
    options: [
      {
        key: "pageSize",
        label: "Format de page",
        type: "select",
        defaultValue: "a4",
        options: [
          { value: "a4", label: "A4 (210 × 297 mm)" },
          { value: "fit", label: "Adapté à l'image" },
        ],
      },
    ],
    steps: [
      "Ajoutez une ou plusieurs images (JPG, PNG, WEBP).",
      "Choisissez le format de page souhaité.",
      "Cliquez sur « Créer le PDF ».",
      "Téléchargez le document généré.",
    ],
    faq: [
      {
        q: "Dans quel ordre les images sont-elles ajoutées ?",
        a: "Les images sont ajoutées dans l'ordre de sélection. Vous pouvez retirer un fichier puis le rajouter pour modifier l'ordre.",
      },
      {
        q: "Le format WEBP est-il pris en charge ?",
        a: "Oui, les fichiers WEBP sont convertis automatiquement en image compatible PDF avant assemblage.",
      },
    ],
    related: ["pdf-to-jpg", "merge-pdf", "compress-pdf"],
    popular: true,
  },
  {
    slug: "pdf-to-jpg",
    name: "PDF vers JPG",
    h1: "Convertir un PDF en images JPG ou PNG",
    seoTitle: "Convertir PDF en JPG ou PNG en ligne | DocuConvert",
    seoDescription:
      "Transformez chaque page de votre PDF en image JPG ou PNG haute qualité. Outil en ligne DocuConvert.",
    short: "Exportez chaque page de votre PDF en image.",
    description:
      "Chaque page du PDF est rasterisée en image haute qualité puis regroupée dans une archive ZIP prête à télécharger. Le rendu est effectué localement sur nos serveurs, sans logiciel tiers ni installation.",
    icon: "image",
    accent: "from-violet-500 to-purple-600",
    categories: ["pdf", "image"],
    accept: ".pdf",
    multiple: false,
    status: "live",
    outputHint: "Archive d'images (.zip)",
    options: [
      {
        key: "format",
        label: "Format d'image",
        type: "select",
        defaultValue: "jpg",
        options: [
          { value: "jpg", label: "JPG" },
          { value: "png", label: "PNG" },
        ],
      },
    ],
    steps: [
      "Sélectionnez le PDF à rasteriser.",
      "Choisissez le format d'image voulu.",
      "Lancez le traitement.",
      "Téléchargez l'archive contenant une image par page.",
    ],
    faq: [
      {
        q: "Le rendu est-il réellement effectué ?",
        a: "Oui. Chaque page est rasterisée sur nos serveurs via un moteur de rendu intégré, puis regroupée dans une archive ZIP. Aucune conversion n'est simulée : si un PDF est illisible ou protégé, l'outil renvoie une erreur explicite.",
      },
      {
        q: "Quel format d'image puis-je choisir ?",
        a: "JPG pour un poids réduit et une compatibilité maximale, ou PNG pour une qualité sans perte. Chaque page devient un fichier image nommé page-001.jpg, page-002.jpg, etc.",
      },
    ],
    related: ["jpg-to-pdf", "split-pdf", "compress-pdf"],
    popular: true,
  },
  {
    slug: "merge-pdf",
    name: "Fusionner PDF",
    h1: "Fusionner plusieurs fichiers PDF en un seul",
    seoTitle: "Fusionner PDF en ligne gratuitement | DocuConvert",
    seoDescription:
      "Combinez plusieurs fichiers PDF en un seul document, dans l'ordre de votre choix. Gratuit, rapide et sans installation.",
    short: "Combinez plusieurs PDF en un document unique.",
    description:
      "Sélectionnez deux fichiers PDF ou plus : DocuConvert les assemble dans l'ordre choisi en conservant la qualité d'origine des pages.",
    icon: "merge",
    accent: "from-blue-600 to-cyan-500",
    categories: ["pdf"],
    accept: ".pdf",
    multiple: true,
    status: "live",
    outputHint: "Fichier PDF fusionné (.pdf)",
    steps: [
      "Ajoutez au moins deux fichiers PDF.",
      "Vérifiez l'ordre des documents dans la liste.",
      "Cliquez sur « Fusionner les PDF ».",
      "Téléchargez le document final.",
    ],
    faq: [
      {
        q: "Combien de fichiers puis-je fusionner ?",
        a: "Jusqu'à 20 fichiers par opération, dans la limite de taille totale de votre offre.",
      },
      {
        q: "La qualité est-elle modifiée ?",
        a: "Non, les pages sont copiées telles quelles, sans recompression.",
      },
    ],
    related: ["split-pdf", "compress-pdf", "organize-pdf"],
    popular: true,
  },
  {
    slug: "split-pdf",
    name: "Diviser un PDF",
    h1: "Diviser un PDF en plusieurs fichiers",
    seoTitle: "Diviser un PDF en ligne gratuitement | DocuConvert",
    seoDescription:
      "Extrayez une plage de pages ou découpez votre PDF en plusieurs documents séparés, directement en ligne.",
    short: "Extrayez les pages qui vous intéressent.",
    description:
      "Indiquez une plage de pages (par exemple 1-3, 7, 10-12) pour créer un nouveau PDF contenant uniquement ces pages.",
    icon: "split",
    accent: "from-indigo-600 to-blue-500",
    categories: ["pdf"],
    accept: ".pdf",
    multiple: false,
    status: "live",
    outputHint: "Fichier PDF (.pdf)",
    options: [
      {
        key: "pages",
        label: "Pages à extraire",
        type: "text",
        placeholder: "Ex : 1-3, 5, 8-10",
        help: "Laissez vide pour extraire la première page.",
      },
    ],
    steps: [
      "Chargez votre PDF.",
      "Saisissez les pages ou plages à extraire.",
      "Lancez la division.",
      "Téléchargez le PDF contenant la sélection.",
    ],
    faq: [
      {
        q: "Quelle syntaxe utiliser pour les pages ?",
        a: "Utilisez des numéros séparés par des virgules et des plages avec un tiret : 1-3, 5, 8-10.",
      },
    ],
    related: ["merge-pdf", "remove-pages-pdf", "organize-pdf"],
  },
  {
    slug: "compress-pdf",
    name: "Compresser PDF",
    h1: "Compresser un fichier PDF en ligne",
    seoTitle: "Compresser un PDF en ligne gratuitement | DocuConvert",
    seoDescription:
      "Réduisez le poids de vos fichiers PDF pour les envoyer par e-mail, sans perdre la lisibilité du document.",
    short: "Réduisez le poids de vos PDF avant envoi.",
    description:
      "DocuConvert optimise la structure interne du document (flux compressés, objets inutiles, métadonnées) pour réduire la taille du fichier tout en conservant les pages intactes.",
    icon: "compress",
    accent: "from-emerald-500 to-teal-600",
    categories: ["pdf"],
    accept: ".pdf",
    multiple: false,
    status: "live",
    outputHint: "Fichier PDF optimisé (.pdf)",
    steps: [
      "Sélectionnez le PDF à alléger.",
      "Cliquez sur « Compresser le PDF ».",
      "Consultez le gain de poids affiché.",
      "Téléchargez le fichier optimisé.",
    ],
    faq: [
      {
        q: "Quel gain puis-je espérer ?",
        a: "Le gain dépend du contenu. Les PDF riches en métadonnées et objets redondants sont fortement réduits ; un PDF déjà optimisé variera peu. Le gain réel est toujours affiché après traitement.",
      },
      {
        q: "La qualité des images est-elle dégradée ?",
        a: "Non. L'optimisation actuelle est sans perte : les images ne sont pas recompressées.",
      },
    ],
    related: ["merge-pdf", "split-pdf", "word-to-pdf"],
    popular: true,
  },
  {
    slug: "rotate-pdf",
    name: "Pivoter un PDF",
    h1: "Faire pivoter les pages d'un PDF",
    seoTitle: "Faire pivoter un PDF en ligne | DocuConvert",
    seoDescription:
      "Tournez les pages de votre PDF de 90, 180 ou 270 degrés et enregistrez définitivement l'orientation.",
    short: "Corrigez l'orientation de vos pages.",
    description:
      "Appliquez une rotation à toutes les pages ou à une sélection, puis enregistrez l'orientation de façon permanente dans le fichier.",
    icon: "rotate",
    accent: "from-amber-500 to-orange-600",
    categories: ["pdf"],
    accept: ".pdf",
    multiple: false,
    status: "live",
    outputHint: "Fichier PDF (.pdf)",
    options: [
      {
        key: "angle",
        label: "Angle de rotation",
        type: "select",
        defaultValue: "90",
        options: [
          { value: "90", label: "90° (sens horaire)" },
          { value: "180", label: "180°" },
          { value: "270", label: "270°" },
        ],
      },
      {
        key: "pages",
        label: "Pages concernées",
        type: "text",
        placeholder: "Toutes les pages par défaut",
        help: "Ex : 1-2, 5. Laissez vide pour tout le document.",
      },
    ],
    steps: [
      "Chargez votre PDF.",
      "Choisissez l'angle et les pages concernées.",
      "Appliquez la rotation.",
      "Téléchargez le document corrigé.",
    ],
    faq: [
      {
        q: "La rotation est-elle définitive ?",
        a: "Oui, l'orientation est écrite dans le fichier PDF : elle sera respectée par tous les lecteurs.",
      },
    ],
    related: ["organize-pdf", "remove-pages-pdf", "split-pdf"],
  },
  {
    slug: "organize-pdf",
    name: "Réorganiser un PDF",
    h1: "Réorganiser les pages d'un PDF",
    seoTitle: "Réorganiser les pages d'un PDF en ligne | DocuConvert",
    seoDescription:
      "Changez l'ordre des pages de votre document PDF en indiquant simplement le nouvel ordre souhaité.",
    short: "Changez l'ordre des pages en un instant.",
    description:
      "Indiquez le nouvel ordre des pages (par exemple 3,1,2) pour générer un PDF réorganisé, sans logiciel de bureau.",
    icon: "organize",
    accent: "from-fuchsia-500 to-violet-600",
    categories: ["pdf"],
    accept: ".pdf",
    multiple: false,
    status: "live",
    outputHint: "Fichier PDF (.pdf)",
    options: [
      {
        key: "order",
        label: "Nouvel ordre des pages",
        type: "text",
        placeholder: "Ex : 3, 1, 2, 4-6",
        help: "Les pages non citées sont ajoutées à la fin dans leur ordre d'origine.",
      },
    ],
    steps: [
      "Chargez le PDF à réorganiser.",
      "Saisissez le nouvel ordre des pages.",
      "Lancez le traitement.",
      "Téléchargez le PDF réorganisé.",
    ],
    faq: [
      {
        q: "Que se passe-t-il si j'oublie une page ?",
        a: "Les pages non mentionnées sont automatiquement ajoutées à la fin du document, dans leur ordre initial.",
      },
    ],
    related: ["rotate-pdf", "remove-pages-pdf", "merge-pdf"],
  },
  {
    slug: "remove-pages-pdf",
    name: "Supprimer des pages",
    h1: "Supprimer des pages d'un PDF",
    seoTitle: "Supprimer des pages d'un PDF en ligne | DocuConvert",
    seoDescription:
      "Effacez les pages inutiles de votre PDF gratuitement et téléchargez immédiatement le document allégé.",
    short: "Retirez les pages inutiles de votre document.",
    description:
      "Sélectionnez les pages à supprimer : DocuConvert génère un nouveau PDF sans ces pages, en conservant la qualité d'origine.",
    icon: "trash",
    accent: "from-rose-500 to-red-600",
    categories: ["pdf"],
    accept: ".pdf",
    multiple: false,
    status: "live",
    outputHint: "Fichier PDF (.pdf)",
    options: [
      {
        key: "pages",
        label: "Pages à supprimer",
        type: "text",
        placeholder: "Ex : 2, 5-7",
      },
    ],
    steps: [
      "Chargez votre PDF.",
      "Indiquez les pages à supprimer.",
      "Lancez le traitement.",
      "Téléchargez le PDF nettoyé.",
    ],
    faq: [
      {
        q: "Puis-je supprimer toutes les pages ?",
        a: "Non, un PDF doit contenir au moins une page. L'outil affiche une erreur explicite dans ce cas.",
      },
    ],
    related: ["split-pdf", "organize-pdf", "rotate-pdf"],
  },
];

export function getTool(slug: string): Tool | undefined {
  return TOOLS.find((t) => t.slug === slug);
}

export const POPULAR_TOOLS = TOOLS.filter((t) => t.popular);

export function toolsByCategory(category: ToolCategory): Tool[] {
  return TOOLS.filter((t) => t.categories.includes(category));
}
