import { promises as fs } from "fs";
import path from "path";
import crypto from "crypto";

/**
 * Stockage local des fichiers de sortie.
 * En production, remplacez ces fonctions par un bucket (Supabase Storage / S3).
 * La politique de conservation est appliquée par `purgeExpired()`.
 */
const ROOT = path.join(process.cwd(), ".data", "files");

export const RETENTION_HOURS = Number(process.env.FILE_RETENTION_HOURS ?? 2);

async function ensureRoot() {
  await fs.mkdir(ROOT, { recursive: true });
}

export async function saveOutput(buffer: Buffer, filename: string) {
  await ensureRoot();
  const id = crypto.randomUUID();
  const key = `${id}__${filename.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
  await fs.writeFile(path.join(ROOT, key), buffer);
  return key;
}

export async function readOutput(key: string): Promise<Buffer | null> {
  if (!/^[a-zA-Z0-9._-]+$/.test(key)) return null;
  try {
    return await fs.readFile(path.join(ROOT, key));
  } catch {
    return null;
  }
}

export async function deleteOutput(key: string) {
  if (!/^[a-zA-Z0-9._-]+$/.test(key)) return;
  try {
    await fs.unlink(path.join(ROOT, key));
  } catch {
    /* déjà supprimé */
  }
}

/** Supprime les fichiers temporaires dont la durée de rétention est dépassée. */
export async function purgeExpired() {
  await ensureRoot();
  const now = Date.now();
  const ttl = RETENTION_HOURS * 3600 * 1000;
  let removed = 0;
  try {
    const entries = await fs.readdir(ROOT);
    for (const entry of entries) {
      const full = path.join(ROOT, entry);
      const stat = await fs.stat(full);
      if (now - stat.mtimeMs > ttl) {
        await fs.unlink(full);
        removed += 1;
      }
    }
  } catch {
    /* ignore */
  }
  return removed;
}
