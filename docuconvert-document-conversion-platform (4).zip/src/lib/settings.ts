import { db } from "@/db";
import { settings, plans } from "@/db/schema";
import { eq, asc } from "drizzle-orm";

export type AdsConfig = {
  enabled: boolean;
  clientId: string;
  slots: Record<string, boolean>;
};

export type SiteConfig = {
  siteName: string;
  heroTitle: string;
  heroSubtitle: string;
  contactEmail: string;
  retentionHours: number;
};

export const DEFAULT_ADS: AdsConfig = {
  enabled: true,
  clientId: process.env.NEXT_PUBLIC_ADSENSE_CLIENT ?? "",
  slots: {
    homeTop: true,
    homeMiddle: true,
    homeBottom: true,
    toolTop: true,
    toolResult: true,
    toolRelated: true,
    blogTop: true,
    blogMiddle: true,
    blogBottom: true,
    blogSidebar: true,
    tutorialUnderVideo: true,
    tutorialBeforeRelated: true,
  },
};

export const DEFAULT_SITE: SiteConfig = {
  siteName: "DocuConvert",
  heroTitle: "Tous vos outils PDF et Word, au même endroit",
  heroSubtitle:
    "Convertissez, compressez et organisez vos documents en quelques secondes. Des outils simples, rapides et accessibles directement en ligne.",
  contactEmail: "contact@docuconvert.app",
  retentionHours: 2,
};

export async function getSetting<T>(key: string, fallback: T): Promise<T> {
  try {
    const rows = await db.select().from(settings).where(eq(settings.key, key)).limit(1);
    if (!rows[0]) return fallback;
    return { ...fallback, ...(rows[0].value as object) } as T;
  } catch {
    return fallback;
  }
}

export async function setSetting(key: string, value: Record<string, unknown>) {
  await db
    .insert(settings)
    .values({ key, value })
    .onConflictDoUpdate({ target: settings.key, set: { value, updatedAt: new Date() } });
}

export const getAdsConfig = () => getSetting<AdsConfig>("ads", DEFAULT_ADS);
export const getSiteConfig = () => getSetting<SiteConfig>("site", DEFAULT_SITE);

export async function getPlans() {
  try {
    return await db.select().from(plans).orderBy(asc(plans.position));
  } catch {
    return [];
  }
}

export async function getPlanByKey(key: string) {
  const rows = await db.select().from(plans).where(eq(plans.key, key)).limit(1);
  return rows[0] ?? null;
}

export function formatPrice(cents: number, currency = "EUR") {
  if (cents === 0) return "0";
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency,
    minimumFractionDigits: cents % 100 === 0 ? 0 : 2,
  }).format(cents / 100);
}
