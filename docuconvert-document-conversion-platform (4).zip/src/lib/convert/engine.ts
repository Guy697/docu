import { PDFDocument, StandardFonts, degrees, rgb } from "pdf-lib";
import mammoth from "mammoth";
import { Document, Packer, Paragraph, HeadingLevel, TextRun } from "docx";

export type ConvertResult = {
  buffer: Buffer;
  filename: string;
  mime: string;
  note?: string;
};

export class ConvertError extends Error {
  code: string;
  constructor(message: string, code = "CONVERT_ERROR") {
    super(message);
    this.code = code;
  }
}

/* ------------------------------------------------------------------ utils */

export function parsePageRanges(input: string | undefined, pageCount: number): number[] {
  if (!input || !input.trim()) return [];
  const result: number[] = [];
  for (const chunk of input.split(",")) {
    const part = chunk.trim();
    if (!part) continue;
    const range = part.match(/^(\d+)\s*-\s*(\d+)$/);
    if (range) {
      const start = Number(range[1]);
      const end = Number(range[2]);
      if (start < 1 || end < start) throw new ConvertError(`Plage de pages invalide : « ${part} ».`);
      for (let i = start; i <= end; i += 1) result.push(i);
    } else if (/^\d+$/.test(part)) {
      result.push(Number(part));
    } else {
      throw new ConvertError(
        `Syntaxe de pages invalide : « ${part} ». Utilisez par exemple 1-3, 5, 8.`,
      );
    }
  }
  const unique = [...new Set(result)];
  const invalid = unique.filter((p) => p < 1 || p > pageCount);
  if (invalid.length) {
    throw new ConvertError(
      `Le document contient ${pageCount} page(s). Page(s) inexistante(s) : ${invalid.join(", ")}.`,
    );
  }
  return unique;
}

const REPLACEMENTS: Record<string, string> = {
  "\u2018": "'",
  "\u2019": "'",
  "\u201A": ",",
  "\u201C": '"',
  "\u201D": '"',
  "\u2013": "-",
  "\u2014": "-",
  "\u2026": "...",
  "\u00A0": " ",
  "\u202F": " ",
  "\u2022": "-",
  "\u2192": "->",
  "\t": "    ",
};

/** WinAnsi ne couvre pas tout l'Unicode : on normalise pour éviter un échec d'encodage. */
function sanitize(text: string) {
  let out = "";
  for (const ch of text) {
    const mapped = REPLACEMENTS[ch];
    if (mapped !== undefined) {
      out += mapped;
      continue;
    }
    const code = ch.codePointAt(0) ?? 0;
    out += code <= 0xff ? ch : "?";
  }
  return out;
}

type Block = { type: "h1" | "h2" | "h3" | "p" | "li"; text: string };

function htmlToBlocks(html: string): Block[] {
  const blocks: Block[] = [];
  const regex = /<(h1|h2|h3|h4|p|li)[^>]*>([\s\S]*?)<\/\1>/gi;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(html)) !== null) {
    const tag = match[1].toLowerCase();
    const text = match[2]
      .replace(/<br\s*\/?>/gi, " ")
      .replace(/<[^>]+>/g, "")
      .replace(/&nbsp;/g, " ")
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&#39;|&apos;/g, "'")
      .replace(/&quot;/g, '"')
      .replace(/\s+/g, " ")
      .trim();
    if (!text) continue;
    const type: Block["type"] =
      tag === "h1" ? "h1" : tag === "h2" ? "h2" : tag === "h3" || tag === "h4" ? "h3" : tag === "li" ? "li" : "p";
    blocks.push({ type, text });
  }
  return blocks;
}

/* --------------------------------------------------------- word -> pdf */

export async function wordToPdf(file: Buffer, originalName: string): Promise<ConvertResult> {
  if (/\.doc$/i.test(originalName)) {
    throw new ConvertError(
      "Les anciens fichiers .doc binaires ne sont pas pris en charge. Enregistrez le document au format .docx puis réessayez.",
      "UNSUPPORTED_FORMAT",
    );
  }
  let html = "";
  try {
    const res = await mammoth.convertToHtml({ buffer: file });
    html = res.value;
  } catch {
    throw new ConvertError(
      "Impossible de lire ce document Word. Le fichier est peut-être corrompu ou protégé.",
      "INVALID_FILE",
    );
  }
  const blocks = htmlToBlocks(html);
  if (!blocks.length) {
    throw new ConvertError(
      "Aucun contenu textuel n'a été trouvé dans ce document Word.",
      "EMPTY_DOCUMENT",
    );
  }

  const pdf = await PDFDocument.create();
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  const pageWidth = 595.28;
  const pageHeight = 841.89;
  const margin = 56;
  const maxWidth = pageWidth - margin * 2;

  let page = pdf.addPage([pageWidth, pageHeight]);
  let y = pageHeight - margin;

  const newPage = () => {
    page = pdf.addPage([pageWidth, pageHeight]);
    y = pageHeight - margin;
  };

  for (const block of blocks) {
    const size = block.type === "h1" ? 20 : block.type === "h2" ? 16 : block.type === "h3" ? 13 : 11;
    const usedFont = block.type.startsWith("h") ? bold : font;
    const lineHeight = size * 1.45;
    const prefix = block.type === "li" ? "•  " : "";
    const words = sanitize(prefix + block.text).split(" ");
    const lines: string[] = [];
    let current = "";
    for (const word of words) {
      const candidate = current ? `${current} ${word}` : word;
      if (usedFont.widthOfTextAtSize(candidate, size) > maxWidth && current) {
        lines.push(current);
        current = word;
      } else {
        current = candidate;
      }
    }
    if (current) lines.push(current);

    if (block.type.startsWith("h")) y -= 8;
    for (const line of lines) {
      if (y - lineHeight < margin) newPage();
      page.drawText(line, {
        x: margin + (block.type === "li" ? 12 : 0),
        y: y - size,
        size,
        font: usedFont,
        color: rgb(0.1, 0.12, 0.16),
      });
      y -= lineHeight;
    }
    y -= block.type === "p" ? 6 : 4;
  }

  const bytes = await pdf.save();
  return {
    buffer: Buffer.from(bytes),
    filename: originalName.replace(/\.[^.]+$/, "") + ".pdf",
    mime: "application/pdf",
    note: `${blocks.length} bloc(s) de texte converti(s) sur ${pdf.getPageCount()} page(s).`,
  };
}

/* --------------------------------------------------------- pdf -> word */

type PdfTextItem = { str: string; transform: number[] };

export async function pdfToWord(file: Buffer, originalName: string): Promise<ConvertResult> {
  const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
  let doc;
  try {
    doc = await pdfjs.getDocument({
      data: new Uint8Array(file),
      useSystemFonts: true,
    }).promise;
  } catch {
    throw new ConvertError(
      "Ce PDF ne peut pas être lu. Il est peut-être protégé par mot de passe ou corrompu.",
      "INVALID_FILE",
    );
  }

  const paragraphs: Paragraph[] = [];
  let totalChars = 0;

  for (let pageNumber = 1; pageNumber <= doc.numPages; pageNumber += 1) {
    const page = await doc.getPage(pageNumber);
    const content = await page.getTextContent();
    const items = content.items as unknown as PdfTextItem[];
    const lines: { y: number; text: string }[] = [];
    for (const item of items) {
      if (!item.str) continue;
      const y = Math.round(item.transform[5]);
      const last = lines[lines.length - 1];
      if (last && Math.abs(last.y - y) <= 2) {
        last.text += item.str;
      } else {
        lines.push({ y, text: item.str });
      }
    }
    const text = lines
      .map((l) => l.text.replace(/\s+/g, " ").trim())
      .filter(Boolean);
    totalChars += text.join("").length;

    if (pageNumber > 1) {
      paragraphs.push(new Paragraph({ text: "", pageBreakBefore: true }));
    }
    paragraphs.push(
      new Paragraph({
        heading: HeadingLevel.HEADING_3,
        children: [new TextRun({ text: `Page ${pageNumber}`, color: "3B5BDB" })],
      }),
    );
    for (const line of text) {
      paragraphs.push(new Paragraph({ children: [new TextRun({ text: line, size: 22 })] }));
    }
  }

  if (totalChars === 0) {
    throw new ConvertError(
      "Aucun texte sélectionnable n'a été détecté : ce PDF est probablement un scan. Une reconnaissance optique (OCR) est nécessaire.",
      "NO_TEXT_LAYER",
    );
  }

  const docx = new Document({ sections: [{ properties: {}, children: paragraphs }] });
  const buffer = await Packer.toBuffer(docx);
  return {
    buffer: Buffer.from(buffer),
    filename: originalName.replace(/\.[^.]+$/, "") + ".docx",
    mime: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    note: `${doc.numPages} page(s) analysée(s), ${totalChars} caractères extraits.`,
  };
}

/* -------------------------------------------------------- images -> pdf */

export async function imagesToPdf(
  files: { buffer: Buffer; name: string }[],
  pageSize: string,
): Promise<ConvertResult> {
  const pdf = await PDFDocument.create();
  for (const file of files) {
    let data = file.buffer;
    let isPng = /\.png$/i.test(file.name);
    if (/\.webp$/i.test(file.name)) {
      const sharp = (await import("sharp")).default;
      data = await sharp(file.buffer).png().toBuffer();
      isPng = true;
    }
    let image;
    try {
      image = isPng ? await pdf.embedPng(data) : await pdf.embedJpg(data);
    } catch {
      try {
        const sharp = (await import("sharp")).default;
        const png = await sharp(file.buffer).png().toBuffer();
        image = await pdf.embedPng(png);
      } catch {
        throw new ConvertError(
          `L'image « ${file.name} » n'a pas pu être lue. Formats acceptés : JPG, PNG, WEBP.`,
          "INVALID_IMAGE",
        );
      }
    }

    if (pageSize === "fit") {
      const page = pdf.addPage([image.width, image.height]);
      page.drawImage(image, { x: 0, y: 0, width: image.width, height: image.height });
    } else {
      const pw = 595.28;
      const ph = 841.89;
      const page = pdf.addPage([pw, ph]);
      const margin = 24;
      const scale = Math.min((pw - margin * 2) / image.width, (ph - margin * 2) / image.height);
      const w = image.width * scale;
      const h = image.height * scale;
      page.drawImage(image, { x: (pw - w) / 2, y: (ph - h) / 2, width: w, height: h });
    }
  }
  const bytes = await pdf.save();
  return {
    buffer: Buffer.from(bytes),
    filename: "images-docuconvert.pdf",
    mime: "application/pdf",
    note: `${files.length} image(s) assemblée(s) en ${pdf.getPageCount()} page(s).`,
  };
}

/* ------------------------------------------------------------- pdf-lib */

async function load(file: Buffer) {
  try {
    return await PDFDocument.load(file, { ignoreEncryption: false });
  } catch {
    throw new ConvertError(
      "Ce fichier PDF ne peut pas être ouvert (fichier corrompu ou protégé par mot de passe).",
      "INVALID_FILE",
    );
  }
}

export async function mergePdf(files: { buffer: Buffer; name: string }[]): Promise<ConvertResult> {
  if (files.length < 2) {
    throw new ConvertError("Sélectionnez au moins deux fichiers PDF à fusionner.", "TOO_FEW_FILES");
  }
  const out = await PDFDocument.create();
  for (const file of files) {
    const src = await load(file.buffer);
    const pages = await out.copyPages(src, src.getPageIndices());
    pages.forEach((p) => out.addPage(p));
  }
  const bytes = await out.save({ useObjectStreams: true });
  return {
    buffer: Buffer.from(bytes),
    filename: "fusion-docuconvert.pdf",
    mime: "application/pdf",
    note: `${files.length} documents fusionnés (${out.getPageCount()} pages).`,
  };
}

export async function splitPdf(
  file: Buffer,
  originalName: string,
  pagesInput?: string,
): Promise<ConvertResult> {
  const src = await load(file);
  const count = src.getPageCount();
  const pages = parsePageRanges(pagesInput, count);
  const selected = pages.length ? pages : [1];
  const out = await PDFDocument.create();
  const copied = await out.copyPages(src, selected.map((p) => p - 1));
  copied.forEach((p) => out.addPage(p));
  const bytes = await out.save({ useObjectStreams: true });
  return {
    buffer: Buffer.from(bytes),
    filename: originalName.replace(/\.[^.]+$/, "") + "-extrait.pdf",
    mime: "application/pdf",
    note: `${selected.length} page(s) extraite(s) sur ${count}.`,
  };
}

export async function compressPdf(file: Buffer, originalName: string): Promise<ConvertResult> {
  const src = await load(file);
  src.setTitle("");
  src.setAuthor("");
  src.setSubject("");
  src.setKeywords([]);
  src.setProducer("DocuConvert");
  src.setCreator("DocuConvert");
  const bytes = await src.save({ useObjectStreams: true, addDefaultPage: false });
  const optimized = Buffer.from(bytes);
  const keepOriginal = optimized.length >= file.length;
  const finalBuffer = keepOriginal ? file : optimized;
  const gain = Math.max(0, Math.round((1 - finalBuffer.length / file.length) * 100));
  return {
    buffer: finalBuffer,
    filename: originalName.replace(/\.[^.]+$/, "") + "-compresse.pdf",
    mime: "application/pdf",
    note: keepOriginal
      ? "Ce PDF était déjà optimisé : le fichier d'origine a été conservé (aucun gain réel possible sans perte de qualité)."
      : `Poids réduit de ${gain} % sans perte de qualité.`,
  };
}

export async function rotatePdf(
  file: Buffer,
  originalName: string,
  angleInput: string | undefined,
  pagesInput: string | undefined,
): Promise<ConvertResult> {
  const angle = Number(angleInput ?? 90);
  if (![90, 180, 270].includes(angle)) {
    throw new ConvertError("Angle invalide. Choisissez 90, 180 ou 270 degrés.", "INVALID_ANGLE");
  }
  const src = await load(file);
  const count = src.getPageCount();
  const target = parsePageRanges(pagesInput, count);
  const indices = target.length ? target.map((p) => p - 1) : src.getPageIndices();
  indices.forEach((i) => {
    const page = src.getPage(i);
    const current = page.getRotation().angle;
    page.setRotation(degrees((current + angle) % 360));
  });
  const bytes = await src.save({ useObjectStreams: true });
  return {
    buffer: Buffer.from(bytes),
    filename: originalName.replace(/\.[^.]+$/, "") + "-pivote.pdf",
    mime: "application/pdf",
    note: `${indices.length} page(s) pivotée(s) de ${angle}°.`,
  };
}

export async function organizePdf(
  file: Buffer,
  originalName: string,
  orderInput: string | undefined,
): Promise<ConvertResult> {
  const src = await load(file);
  const count = src.getPageCount();
  const order = parsePageRanges(orderInput, count);
  if (!order.length) {
    throw new ConvertError(
      "Indiquez le nouvel ordre des pages, par exemple : 3, 1, 2.",
      "MISSING_ORDER",
    );
  }
  const remaining = Array.from({ length: count }, (_, i) => i + 1).filter((p) => !order.includes(p));
  const finalOrder = [...order, ...remaining];
  const out = await PDFDocument.create();
  const copied = await out.copyPages(src, finalOrder.map((p) => p - 1));
  copied.forEach((p) => out.addPage(p));
  const bytes = await out.save({ useObjectStreams: true });
  return {
    buffer: Buffer.from(bytes),
    filename: originalName.replace(/\.[^.]+$/, "") + "-reorganise.pdf",
    mime: "application/pdf",
    note: `Nouvel ordre appliqué : ${finalOrder.join(", ")}.`,
  };
}

export async function removePages(
  file: Buffer,
  originalName: string,
  pagesInput: string | undefined,
): Promise<ConvertResult> {
  const src = await load(file);
  const count = src.getPageCount();
  const pages = parsePageRanges(pagesInput, count);
  if (!pages.length) {
    throw new ConvertError("Indiquez au moins une page à supprimer.", "MISSING_PAGES");
  }
  if (pages.length >= count) {
    throw new ConvertError("Impossible de supprimer toutes les pages du document.", "EMPTY_RESULT");
  }
  const keep = Array.from({ length: count }, (_, i) => i + 1).filter((p) => !pages.includes(p));
  const out = await PDFDocument.create();
  const copied = await out.copyPages(src, keep.map((p) => p - 1));
  copied.forEach((p) => out.addPage(p));
  const bytes = await out.save({ useObjectStreams: true });
  return {
    buffer: Buffer.from(bytes),
    filename: originalName.replace(/\.[^.]+$/, "") + "-nettoye.pdf",
    mime: "application/pdf",
    note: `${pages.length} page(s) supprimée(s), ${keep.length} conservée(s).`,
  };
}

/* --------------------------------------------------------- pdf -> image */

/**
 * Rasterise chaque page du PDF en image (JPG ou PNG) et renvoie une archive ZIP.
 * Le rendu est réalisé localement via pdf-to-img (+ @napi-rs/canvas) — aucun
 * service externe n'est requis. Si PDF_RENDER_API_URL est défini, il est possible
 * d'y déléguer le rendu, mais la passe locale ci-dessous est toujours disponible.
 */
export async function pdfToImage(
  file: Buffer,
  originalName: string,
  format: string,
): Promise<ConvertResult> {
  const { pdf } = await import("pdf-to-img");
  const JSZip = (await import("jszip")).default;

  let doc;
  try {
    doc = await pdf(new Uint8Array(file), { scale: 2 });
  } catch {
    throw new ConvertError(
      "Ce fichier PDF ne peut pas être lu (fichier corrompu ou protégé par mot de passe).",
      "INVALID_FILE",
    );
  }

  const zip = new JSZip();
  let pageCount = 0;
  for await (const page of doc) {
    pageCount += 1;
    let buffer: Buffer = Buffer.from(page);
    if (format === "jpg") {
      const sharp = (await import("sharp")).default;
      buffer = await sharp(buffer).jpeg({ quality: 92 }).toBuffer();
    }
    const ext = format === "jpg" ? "jpg" : "png";
    zip.file(`page-${String(pageCount).padStart(3, "0")}.${ext}`, buffer);
  }

  if (pageCount === 0) {
    throw new ConvertError(
      "Aucune page n'a pu être rendue. Le PDF est peut-être protégé ou vide.",
      "EMPTY_RESULT",
    );
  }

  const bytes = await zip.generateAsync({ type: "nodebuffer" });
  const ext = format === "jpg" ? "jpg" : "png";
  return {
    buffer: Buffer.from(bytes),
    filename: originalName.replace(/\.[^.]+$/, "") + "-images.zip",
    mime: "application/zip",
    note: `${pageCount} page(s) exportée(s) en ${ext.toUpperCase()} dans une archive ZIP.`,
  };
}
