"use client";

import Link from "next/link";
import { useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { Logo } from "./Icons";
import type { SessionUser } from "@/lib/auth";

const NAV = [
  { href: "/", label: "Accueil" },
  { href: "/outils/pdf", label: "Outils PDF" },
  { href: "/outils/word", label: "Outils Word" },
  { href: "/blog", label: "Blog" },
  { href: "/tutoriels", label: "Tutoriels" },
  { href: "/tarifs", label: "Tarifs" },
];

export default function Header({ user }: { user: SessionUser | null }) {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const router = useRouter();

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.refresh();
    router.push("/");
  };

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200/80 bg-white/90 backdrop-blur">
      <div className="container-page flex h-16 items-center justify-between gap-4">
        <Link href="/" aria-label="DocuConvert — accueil">
          <Logo />
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((item) => {
            const active = item.href === "/" ? pathname === "/" : pathname.startsWith(item.href);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                  active ? "bg-brand-50 text-brand-700" : "text-ink-700 hover:bg-slate-100"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <div className="hidden items-center gap-2 lg:flex">
          {user ? (
            <>
              {user.role === "admin" && (
                <Link href="/admin" className="btn-ghost">
                  Admin
                </Link>
              )}
              <Link href="/dashboard" className="btn-secondary">
                Tableau de bord
              </Link>
              <button onClick={logout} className="btn-ghost" type="button">
                Déconnexion
              </button>
            </>
          ) : (
            <>
              <Link href="/connexion" className="btn-ghost">
                Se connecter
              </Link>
              <Link href="/inscription" className="btn-primary">
                Commencer gratuitement
              </Link>
            </>
          )}
        </div>

        <button
          type="button"
          aria-label="Ouvrir le menu"
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
          className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 text-ink-700 lg:hidden"
        >
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2">
            {open ? (
              <path d="m6 6 12 12M18 6 6 18" strokeLinecap="round" />
            ) : (
              <path d="M4 7h16M4 12h16M4 17h16" strokeLinecap="round" />
            )}
          </svg>
        </button>
      </div>

      {open && (
        <div className="border-t border-slate-200 bg-white lg:hidden">
          <div className="container-page flex flex-col gap-1 py-4">
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2.5 text-sm font-medium text-ink-700 hover:bg-slate-100"
              >
                {item.label}
              </Link>
            ))}
            <div className="mt-3 flex flex-col gap-2 border-t border-slate-100 pt-3">
              {user ? (
                <>
                  <Link href="/dashboard" className="btn-secondary" onClick={() => setOpen(false)}>
                    Tableau de bord
                  </Link>
                  {user.role === "admin" && (
                    <Link href="/admin" className="btn-secondary" onClick={() => setOpen(false)}>
                      Espace admin
                    </Link>
                  )}
                  <button className="btn-ghost" onClick={logout} type="button">
                    Déconnexion
                  </button>
                </>
              ) : (
                <>
                  <Link href="/connexion" className="btn-secondary" onClick={() => setOpen(false)}>
                    Se connecter
                  </Link>
                  <Link href="/inscription" className="btn-primary" onClick={() => setOpen(false)}>
                    Commencer gratuitement
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
