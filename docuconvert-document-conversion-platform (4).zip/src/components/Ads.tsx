import { getAdsConfig } from "@/lib/settings";

type Size = "leaderboard" | "rectangle" | "sidebar" | "mobile";

const SIZES: Record<Size, { className: string; label: string }> = {
  leaderboard: { className: "min-h-[90px] md:min-h-[90px]", label: "728 × 90" },
  rectangle: { className: "min-h-[250px]", label: "336 × 280" },
  sidebar: { className: "min-h-[600px]", label: "300 × 600" },
  mobile: { className: "min-h-[100px]", label: "320 × 100" },
};

/**
 * Emplacement publicitaire AdSense.
 * - Chaque emplacement est activable/désactivable depuis /admin/publicites.
 * - Si aucun identifiant AdSense n'est configuré, un fallback neutre est affiché
 *   (jamais de fausse publicité ni de faux bouton).
 */
export async function AdSlot({
  slot,
  size = "leaderboard",
  className = "",
  adSlotId,
}: {
  slot: string;
  size?: Size;
  className?: string;
  adSlotId?: string;
}) {
  const config = await getAdsConfig();
  if (!config.enabled || config.slots?.[slot] === false) return null;
  const { className: sizeClass, label } = SIZES[size];

  return (
    <aside
      aria-label="Emplacement publicitaire"
      className={`w-full ${className}`}
      data-ad-slot={slot}
    >
      <div
        className={`flex w-full flex-col items-center justify-center rounded-xl border border-dashed border-slate-200 bg-slate-50/70 px-4 py-3 text-center ${sizeClass}`}
      >
        {config.clientId ? (
          <ins
            className="adsbygoogle block w-full"
            style={{ display: "block" }}
            data-ad-client={config.clientId}
            data-ad-slot={adSlotId ?? ""}
            data-ad-format="auto"
            data-full-width-responsive="true"
          />
        ) : (
          <>
            <span className="text-[11px] font-semibold uppercase tracking-widest text-slate-400">
              Espace publicitaire
            </span>
            <span className="mt-1 text-xs text-slate-400">
              Format {label} — activé après configuration d&apos;AdSense
            </span>
          </>
        )}
      </div>
    </aside>
  );
}

export const AdBannerTop = (props: { slot: string; className?: string }) => (
  <AdSlot {...props} size="leaderboard" />
);
export const AdBannerContent = (props: { slot: string; className?: string }) => (
  <AdSlot {...props} size="rectangle" />
);
export const AdBannerSidebar = (props: { slot: string; className?: string }) => (
  <AdSlot {...props} size="sidebar" />
);
export const AdBannerBottom = (props: { slot: string; className?: string }) => (
  <AdSlot {...props} size="mobile" />
);
