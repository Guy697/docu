"use client";

import { useCallback, useMemo, useRef, useState } from "react";
import Link from "next/link";
import type { Tool } from "@/lib/tools";
import { ToolIcon } from "./Icons";
import { formatBytes } from "@/lib/format";

type Result = {
  filename: string;
  size: number;
  inputSize: number;
  note?: string;
  downloadUrl: string;
  expiresAt: string;
};



export default function ToolWorkspace({
  tools,
  initialSlug,
  maxFileMb = 10,
  allowSwitch = false,
}: {
  tools: Tool[];
  initialSlug: string;
  maxFileMb?: number;
  allowSwitch?: boolean;
}) {
  const [slug, setSlug] = useState(initialSlug);
  const tool = useMemo(() => tools.find((t) => t.slug === slug) ?? tools[0], [tools, slug]);
  const [files, setFiles] = useState<File[]>([]);
  const [options, setOptions] = useState<Record<string, string>>({});
  const [progress, setProgress] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [upgrade, setUpgrade] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const [dragging, setDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const reset = () => {
    setResult(null);
    setError(null);
    setUpgrade(false);
    setProgress(0);
  };

  const addFiles = useCallback(
    (incoming: FileList | null) => {
      if (!incoming) return;
      reset();
      const list = Array.from(incoming);
      const allowed = tool.accept.split(",").map((e) => e.trim().toLowerCase());
      const valid: File[] = [];
      for (const file of list) {
        const ext = "." + (file.name.split(".").pop() ?? "").toLowerCase();
        if (!allowed.includes(ext)) {
          setError(`« ${file.name} » : format non pris en charge. Formats acceptés : ${allowed.join(", ")}.`);
          continue;
        }
        if (file.size > maxFileMb * 1024 * 1024) {
          setError(`« ${file.name} » dépasse la taille maximale de ${maxFileMb} Mo.`);
          setUpgrade(true);
          continue;
        }
        valid.push(file);
      }
      if (!valid.length) return;
      setFiles((prev) => (tool.multiple ? [...prev, ...valid].slice(0, 20) : [valid[0]]));
    },
    [tool, maxFileMb],
  );

  const removeFile = (index: number) => {
    reset();
    setFiles((prev) => prev.filter((_, i) => i !== index));
  };

  const run = () => {
    if (!files.length) {
      setError("Sélectionnez d'abord un fichier.");
      return;
    }
    reset();
    setBusy(true);
    setProgress(3);

    const form = new FormData();
    form.append("tool", tool.slug);
    files.forEach((f) => form.append("files", f));
    for (const option of tool.options ?? []) {
      form.append(option.key, options[option.key] ?? option.defaultValue ?? "");
    }

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/convert");
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) {
        setProgress(Math.min(85, Math.round((event.loaded / event.total) * 80) + 5));
      }
    };
    xhr.onload = () => {
      setBusy(false);
      setProgress(100);
      try {
        const data = JSON.parse(xhr.responseText);
        if (xhr.status >= 200 && xhr.status < 300) {
          setResult(data as Result);
        } else {
          setError(data.error ?? "Le traitement a échoué.");
          setUpgrade(Boolean(data.upgrade));
          setProgress(0);
        }
      } catch {
        setError("Réponse inattendue du serveur. Aucun fichier n'a été produit.");
        setProgress(0);
      }
    };
    xhr.onerror = () => {
      setBusy(false);
      setProgress(0);
      setError("Connexion interrompue. Vérifiez votre réseau puis réessayez.");
    };
    xhr.send(form);
  };

  return (
    <div className="w-full">
      {allowSwitch && (
        <div className="mb-5">
          <label className="label" htmlFor="tool-select">
            Type de conversion
          </label>
          <select
            id="tool-select"
            className="input"
            value={slug}
            onChange={(e) => {
              setSlug(e.target.value);
              setFiles([]);
              reset();
            }}
          >
            {tools.map((t) => (
              <option key={t.slug} value={t.slug}>
                {t.name} — {t.short}
              </option>
            ))}
          </select>
        </div>
      )}

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragging(true);
        }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragging(false);
          addFiles(e.dataTransfer.files);
        }}
        className={`relative flex flex-col items-center justify-center rounded-2xl border-2 border-dashed px-6 py-10 text-center transition-colors ${
          dragging ? "border-brand-500 bg-brand-50" : "border-slate-300 bg-slate-50/60 hover:border-brand-400"
        }`}
      >
        <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-brand-600 shadow-sm">
          <ToolIcon name={tool.icon} className="h-7 w-7" />
        </span>
        <p className="mt-4 text-base font-semibold text-ink-900">
          Glissez-déposez {tool.multiple ? "vos fichiers" : "votre fichier"} ici
        </p>
        <p className="mt-1 text-sm text-ink-500">
          Formats acceptés : {tool.accept.replaceAll(",", ", ")} · Taille max. {maxFileMb} Mo
        </p>
        <button type="button" className="btn-primary mt-5" onClick={() => inputRef.current?.click()}>
          Choisir un fichier
        </button>
        <input
          ref={inputRef}
          type="file"
          className="hidden"
          accept={tool.accept}
          multiple={tool.multiple}
          onChange={(e) => addFiles(e.target.files)}
        />
        <p className="mt-4 flex items-center gap-1.5 text-xs text-ink-500">
          <svg viewBox="0 0 24 24" className="h-4 w-4 text-emerald-500" fill="none" stroke="currentColor" strokeWidth="1.8">
            <path d="M12 3 5 6v5c0 4.4 3 8.2 7 10 4-1.8 7-5.6 7-10V6l-7-3Z" strokeLinejoin="round" />
          </svg>
          Transfert chiffré · fichiers supprimés automatiquement après traitement
        </p>
      </div>

      {files.length > 0 && (
        <ul className="mt-4 space-y-2">
          {files.map((file, index) => (
            <li
              key={`${file.name}-${index}`}
              className="flex items-center justify-between gap-3 rounded-xl border border-slate-200 bg-white px-4 py-3"
            >
              <div className="flex min-w-0 items-center gap-3">
                <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-brand-600">
                  <ToolIcon name={tool.icon} className="h-4.5 w-4.5" />
                </span>
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-ink-900">{file.name}</p>
                  <p className="text-xs text-ink-500">{formatBytes(file.size)}</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => removeFile(index)}
                className="rounded-lg px-2 py-1 text-xs font-medium text-ink-500 hover:bg-slate-100 hover:text-rose-600"
              >
                Retirer
              </button>
            </li>
          ))}
        </ul>
      )}

      {tool.options && tool.options.length > 0 && (
        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          {tool.options.map((option) => (
            <div key={option.key}>
              <label className="label" htmlFor={`opt-${option.key}`}>
                {option.label}
              </label>
              {option.type === "select" ? (
                <select
                  id={`opt-${option.key}`}
                  className="input"
                  value={options[option.key] ?? option.defaultValue ?? ""}
                  onChange={(e) => setOptions((p) => ({ ...p, [option.key]: e.target.value }))}
                >
                  {option.options?.map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
              ) : (
                <input
                  id={`opt-${option.key}`}
                  className="input"
                  placeholder={option.placeholder}
                  value={options[option.key] ?? ""}
                  onChange={(e) => setOptions((p) => ({ ...p, [option.key]: e.target.value }))}
                />
              )}
              {option.help && <p className="mt-1 text-xs text-ink-500">{option.help}</p>}
            </div>
          ))}
        </div>
      )}

      {tool.status === "needs-integration" && (
        <div className="mt-5 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">
          <strong className="font-semibold">Intégration requise.</strong> {tool.statusNote}
        </div>
      )}

      {busy && (
        <div className="mt-5">
          <div className="mb-2 flex items-center justify-between text-xs font-medium text-ink-500">
            <span>Traitement en cours…</span>
            <span>{progress}%</span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200">
            <div
              className="h-full rounded-full bg-gradient-to-r from-brand-500 to-violet-500 transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      )}

      {error && (
        <div className="mt-5 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
          <p>{error}</p>
          {upgrade && (
            <Link href="/tarifs" className="mt-2 inline-block font-semibold underline underline-offset-2">
              Voir les offres Premium
            </Link>
          )}
        </div>
      )}

      {result && (
        <div className="mt-5 rounded-2xl border border-emerald-200 bg-emerald-50 p-5">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="flex items-center gap-2 text-sm font-semibold text-emerald-800">
                <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2.2">
                  <path d="m5 13 4 4L19 7" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
                Conversion réussie
              </p>
              <p className="mt-1 text-sm text-emerald-900">{result.filename}</p>
              <p className="text-xs text-emerald-700">
                {formatBytes(result.inputSize)} → {formatBytes(result.size)}
                {result.note ? ` · ${result.note}` : ""}
              </p>
            </div>
            <a href={result.downloadUrl} className="btn-primary" download>
              Télécharger le fichier
            </a>
          </div>
          <p className="mt-3 text-xs text-emerald-700">
            Disponible jusqu&apos;au {new Date(result.expiresAt).toLocaleString("fr-FR")} puis supprimé
            automatiquement.
          </p>
        </div>
      )}

      <div className="mt-6 flex flex-wrap items-center gap-3">
        <button type="button" className="btn-primary px-7 py-3 text-base" onClick={run} disabled={busy}>
          {busy ? "Traitement…" : tool.slug === "merge-pdf" ? "Fusionner les PDF" : `Lancer ${tool.name.toLowerCase()}`}
        </button>
        {(files.length > 0 || result) && (
          <button
            type="button"
            className="btn-secondary"
            onClick={() => {
              setFiles([]);
              reset();
            }}
          >
            Réinitialiser
          </button>
        )}
        <span className="text-xs text-ink-500">Sortie : {tool.outputHint}</span>
      </div>
    </div>
  );
}
