"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function AuthForm({ mode }: { mode: "login" | "register" }) {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    const res = await fetch(`/api/auth/${mode === "login" ? "login" : "register"}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password, name }),
    });
    const data = await res.json().catch(() => ({}));
    setBusy(false);
    if (!res.ok) {
      setError(data.error ?? "Une erreur est survenue.");
      return;
    }
    router.refresh();
    router.push(data.role === "admin" ? "/admin" : "/dashboard");
  };

  return (
    <form onSubmit={submit} className="card mx-auto w-full max-w-md p-8">
      <h1 className="text-2xl font-bold text-ink-900">
        {mode === "login" ? "Se connecter" : "Créer un compte gratuit"}
      </h1>
      <p className="mt-2 text-sm text-ink-500">
        {mode === "login"
          ? "Accédez à votre tableau de bord et à votre historique de conversions."
          : "5 conversions par jour offertes, sans carte bancaire."}
      </p>

      {mode === "register" && (
        <div className="mt-6">
          <label className="label" htmlFor="name">Nom</label>
          <input id="name" className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Votre nom" />
        </div>
      )}

      <div className="mt-4">
        <label className="label" htmlFor="email">Adresse e-mail</label>
        <input
          id="email"
          type="email"
          required
          className="input"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="vous@exemple.com"
        />
      </div>

      <div className="mt-4">
        <label className="label" htmlFor="password">Mot de passe</label>
        <input
          id="password"
          type="password"
          required
          minLength={8}
          className="input"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="8 caractères minimum"
        />
      </div>

      {error && (
        <p className="mt-4 rounded-xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
          {error}
        </p>
      )}

      <button type="submit" className="btn-primary mt-6 w-full py-3" disabled={busy}>
        {busy ? "Veuillez patienter…" : mode === "login" ? "Se connecter" : "Créer mon compte"}
      </button>

      <p className="mt-5 text-center text-sm text-ink-500">
        {mode === "login" ? (
          <>
            Pas encore de compte ?{" "}
            <Link href="/inscription" className="font-medium text-brand-600 hover:underline">
              Inscrivez-vous
            </Link>
          </>
        ) : (
          <>
            Déjà inscrit ?{" "}
            <Link href="/connexion" className="font-medium text-brand-600 hover:underline">
              Connectez-vous
            </Link>
          </>
        )}
      </p>

      {mode === "login" && (
        <p className="mt-6 rounded-xl bg-slate-50 px-4 py-3 text-xs text-ink-500">
          Comptes de démonstration : <strong>admin@docuconvert.app / Admin1234!</strong> ·{" "}
          <strong>demo@docuconvert.app / Demo1234!</strong>
        </p>
      )}
    </form>
  );
}
