import Link from "next/link";
import type { Tool } from "@/lib/tools";
import { ToolIcon } from "./Icons";

export default function ToolCard({ tool }: { tool: Tool }) {
  return (
    <div className="card group flex h-full flex-col p-6 transition-transform duration-200 hover:-translate-y-1">
      <span
        className={`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${tool.accent} text-white shadow-sm`}
      >
        <ToolIcon name={tool.icon} />
      </span>
      <h3 className="mt-4 text-base font-semibold text-ink-900">{tool.name}</h3>
      <p className="mt-2 flex-1 text-sm leading-relaxed text-ink-500">{tool.short}</p>
      <div className="mt-5 flex items-center justify-between">
        <Link
          href={`/${tool.slug}`}
          className="btn-secondary px-4 py-2 group-hover:border-brand-400 group-hover:text-brand-700"
        >
          Utiliser
        </Link>
        {tool.status === "needs-integration" && (
          <span className="badge bg-amber-50 text-amber-700">Configuration requise</span>
        )}
      </div>
    </div>
  );
}
