import Link from "next/link";
import { Logo } from "./Icons";
import { TOOLS } from "@/lib/tools";

const SOCIALS = [
  { label: "YouTube", href: "https://youtube.com", d: "M21.6 7.2a2.6 2.6 0 0 0-1.8-1.8C18.1 5 12 5 12 5s-6.1 0-7.8.4A2.6 2.6 0 0 0 2.4 7.2 27 27 0 0 0 2 12a27 27 0 0 0 .4 4.8 2.6 2.6 0 0 0 1.8 1.8C5.9 19 12 19 12 19s6.1 0 7.8-.4a2.6 2.6 0 0 0 1.8-1.8A27 27 0 0 0 22 12a27 27 0 0 0-.4-4.8ZM10 15V9l5 3-5 3Z" },
  { label: "X", href: "https://x.com", d: "M17.5 3h3l-6.6 7.6L22 21h-6l-4.3-5.7L6.6 21H3.5l7-8.1L2.4 3h6.2l3.9 5.2L17.5 3Z" },
  { label: "LinkedIn", href: "https://linkedin.com", d: "M4.98 3.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5ZM3 9h4v12H3V9Zm7 0h3.8v1.7h.05c.53-.95 1.83-1.95 3.77-1.95 4.03 0 4.78 2.5 4.78 5.76V21h-4v-5.6c0-1.34-.03-3.06-1.9-3.06-1.9 0-2.2 1.45-2.2 2.96V21h-4V9Z" },
  { label: "Facebook", href: "https://facebook.com", d: "M13.5 21v-8h2.7l.4-3.1h-3.1V7.9c0-.9.25-1.5 1.55-1.5h1.65V3.6c-.29-.04-1.28-.12-2.43-.12-2.4 0-4.04 1.47-4.04 4.16V9.9H7.5V13h2.73v8h3.27Z" },
];

export default function Footer() {
  return (
    <footer className="mt-20 border-t border-slate-200 bg-white">
      <div className="container-page grid gap-10 py-14 md:grid-cols-2 lg:grid-cols-5">
        <div className="lg:col-span-2">
          <Logo />
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-ink-500">
            DocuConvert réunit vos outils PDF et Word dans une interface simple, rapide et sécurisée.
            Traitement chiffré, suppression automatique des fichiers temporaires.
          </p>
          <div className="mt-5 flex gap-2">
            {SOCIALS.map((s) => (
              <a
                key={s.label}
                href={s.href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={s.label}
                className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-ink-500 transition-colors hover:border-brand-300 hover:text-brand-600"
              >
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor">
                  <path d={s.d} />
                </svg>
              </a>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-ink-900">Outils populaires</h3>
          <ul className="mt-4 space-y-2.5 text-sm text-ink-500">
            {TOOLS.slice(0, 6).map((t) => (
              <li key={t.slug}>
                <Link href={`/${t.slug}`} className="hover:text-brand-600">
                  {t.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-ink-900">Ressources</h3>
          <ul className="mt-4 space-y-2.5 text-sm text-ink-500">
            <li><Link href="/a-propos" className="hover:text-brand-600">À propos</Link></li>
            <li><Link href="/contact" className="hover:text-brand-600">Contact</Link></li>
            <li><Link href="/blog" className="hover:text-brand-600">Blog</Link></li>
            <li><Link href="/tutoriels" className="hover:text-brand-600">Tutoriels</Link></li>
            <li><Link href="/tarifs" className="hover:text-brand-600">Tarifs</Link></li>
            <li><Link href="/outils" className="hover:text-brand-600">Tous les outils</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold text-ink-900">Légal</h3>
          <ul className="mt-4 space-y-2.5 text-sm text-ink-500">
            <li><Link href="/confidentialite" className="hover:text-brand-600">Politique de confidentialité</Link></li>
            <li><Link href="/conditions" className="hover:text-brand-600">Conditions d&apos;utilisation</Link></li>
            <li><Link href="/cookies" className="hover:text-brand-600">Politique relative aux cookies</Link></li>
            <li><Link href="/mentions-legales" className="hover:text-brand-600">Mentions légales</Link></li>
          </ul>
        </div>
      </div>

      <div className="border-t border-slate-100">
        <div className="container-page flex flex-col items-center justify-between gap-3 py-6 text-xs text-ink-500 sm:flex-row">
          <p>© {new Date().getFullYear()} DocuConvert. Tous droits réservés.</p>
          <p>Fichiers supprimés automatiquement après traitement · Hébergement européen</p>
        </div>
      </div>
    </footer>
  );
}
