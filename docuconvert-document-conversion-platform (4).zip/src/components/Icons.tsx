type Props = { className?: string };

const base = "h-6 w-6";

export function ToolIcon({ name, className }: { name: string; className?: string }) {
  const cn = className ?? base;
  switch (name) {
    case "word":
      return (
        <svg viewBox="0 0 24 24" fill="none" className={cn} stroke="currentColor" strokeWidth="1.7">
          <path d="M14 2H7a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7l-5-5Z" strokeLinejoin="round" />
          <path d="M14 2v5h5" strokeLinejoin="round" />
          <path d="m8.5 12 1.3 4.5L11 13l1.2 3.5L13.5 12" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "pdf":
      return (
        <svg viewBox="0 0 24 24" fill="none" className={cn} stroke="currentColor" strokeWidth="1.7">
          <path d="M14 2H7a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7l-5-5Z" strokeLinejoin="round" />
          <path d="M14 2v5h5" strokeLinejoin="round" />
          <path d="M8.5 17v-4.2h1.3a1.2 1.2 0 0 1 0 2.4H8.5M13.5 17v-4.2h1.1a2.1 2.1 0 0 1 0 4.2h-1.1Z" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "image":
      return (
        <svg viewBox="0 0 24 24" fill="none" className={cn} stroke="currentColor" strokeWidth="1.7">
          <rect x="3" y="4" width="18" height="16" rx="2.5" />
          <circle cx="8.5" cy="9.5" r="1.6" />
          <path d="m4 17 4.5-4.5L12 16l3-3 5 5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "merge":
      return (
        <svg viewBox="0 0 24 24" fill="none" className={cn} stroke="currentColor" strokeWidth="1.7">
          <path d="M6 3v6a4 4 0 0 0 4 4h8M6 21v-6a4 4 0 0 1 4-4h8" strokeLinecap="round" />
          <path d="m15 10 3 3-3 3" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "split":
      return (
        <svg viewBox="0 0 24 24" fill="none" className={cn} stroke="currentColor" strokeWidth="1.7">
          <path d="M18 3v6a4 4 0 0 1-4 4H6m12 8v-6a4 4 0 0 0-4-4H6" strokeLinecap="round" />
          <path d="m9 10-3 3 3 3" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "compress":
      return (
        <svg viewBox="0 0 24 24" fill="none" className={cn} stroke="currentColor" strokeWidth="1.7">
          <path d="M8 4v4H4M16 4v4h4M8 20v-4H4M16 20v-4h4" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M9 12h6" strokeLinecap="round" />
        </svg>
      );
    case "rotate":
      return (
        <svg viewBox="0 0 24 24" fill="none" className={cn} stroke="currentColor" strokeWidth="1.7">
          <path d="M20 12a8 8 0 1 1-2.6-5.9" strokeLinecap="round" />
          <path d="M20 4v4h-4" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      );
    case "organize":
      return (
        <svg viewBox="0 0 24 24" fill="none" className={cn} stroke="currentColor" strokeWidth="1.7">
          <rect x="3" y="4" width="7" height="7" rx="1.6" />
          <rect x="14" y="4" width="7" height="7" rx="1.6" />
          <rect x="3" y="14" width="7" height="6" rx="1.6" />
          <rect x="14" y="14" width="7" height="6" rx="1.6" />
        </svg>
      );
    case "trash":
      return (
        <svg viewBox="0 0 24 24" fill="none" className={cn} stroke="currentColor" strokeWidth="1.7">
          <path d="M4 7h16M9 7V5a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2" strokeLinecap="round" />
          <path d="M6 7h12l-1 13a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1L6 7Z" strokeLinejoin="round" />
        </svg>
      );
    default:
      return (
        <svg viewBox="0 0 24 24" fill="none" className={cn} stroke="currentColor" strokeWidth="1.7">
          <circle cx="12" cy="12" r="9" />
        </svg>
      );
  }
}

export function Logo({ className }: Props) {
  return (
    <span className={`flex items-center gap-2 ${className ?? ""}`}>
      <span className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-brand-500 to-violet-600 text-white shadow-sm">
        <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5" stroke="currentColor" strokeWidth="2">
          <path d="M14 3H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7l-4-4Z" strokeLinejoin="round" />
          <path d="M13 3v5h5" strokeLinejoin="round" />
          <path d="m9.5 14 2 2 3.5-4" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </span>
      <span className="text-lg font-bold tracking-tight text-ink-900">
        Docu<span className="text-brand-600">Convert</span>
      </span>
    </span>
  );
}

export function Check({ className }: Props) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className ?? "h-5 w-5"} stroke="currentColor" strokeWidth="2.2">
      <path d="m5 13 4 4L19 7" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function Feature({ name, className }: { name: string; className?: string }) {
  const cn = className ?? "h-6 w-6";
  const paths: Record<string, React.ReactNode> = {
    bolt: <path d="M13 2 4 14h6l-1 8 9-12h-6l1-8Z" strokeLinejoin="round" />,
    sparkle: <path d="M12 3v4m0 10v4M3 12h4m10 0h4M6 6l2.5 2.5M15.5 15.5 18 18M18 6l-2.5 2.5M8.5 15.5 6 18" strokeLinecap="round" />,
    layers: <path d="m12 3 9 5-9 5-9-5 9-5Zm9 9-9 5-9-5m18 4-9 5-9-5" strokeLinejoin="round" />,
    devices: (
      <>
        <rect x="2" y="4" width="14" height="10" rx="2" />
        <rect x="16" y="9" width="6" height="11" rx="1.6" />
      </>
    ),
    shield: <path d="M12 3 5 6v5c0 4.4 3 8.2 7 10 4-1.8 7-5.6 7-10V6l-7-3Z" strokeLinejoin="round" />,
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" strokeLinecap="round" />
      </>
    ),
  };
  return (
    <svg viewBox="0 0 24 24" fill="none" className={cn} stroke="currentColor" strokeWidth="1.7">
      {paths[name] ?? paths.bolt}
    </svg>
  );
}
