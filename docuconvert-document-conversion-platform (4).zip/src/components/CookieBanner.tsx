"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

const KEY = "dc_consent";

export default function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!localStorage.getItem(KEY)) setVisible(true);
  }, []);

  const choose = (value: "all" | "essential") => {
    localStorage.setItem(KEY, JSON.stringify({ value, date: new Date().toISOString() }));
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed inset-x-3 bottom-3 z-50 mx-auto max-w-3xl rounded-2xl border border-slate-200 bg-white p-5 shadow-lg sm:inset-x-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-ink-700">
          Nous utilisons des cookies nécessaires au fonctionnement du service et, avec votre accord, des
          cookies de mesure d&apos;audience et de personnalisation publicitaire.{" "}
          <Link href="/cookies" className="font-medium text-brand-600 underline underline-offset-2">
            En savoir plus
          </Link>
        </p>
        <div className="flex shrink-0 gap-2">
          <button className="btn-secondary" type="button" onClick={() => choose("essential")}>
            Refuser
          </button>
          <button className="btn-primary" type="button" onClick={() => choose("all")}>
            Tout accepter
          </button>
        </div>
      </div>
    </div>
  );
}
