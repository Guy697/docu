import { renderMarkdown } from "@/lib/markdown";

export const LEGAL_CONTENT: Record<string, { title: string; description: string; body: string }> = {
  confidentialite: {
    title: "Politique de confidentialité",
    description:
      "Comment DocuConvert collecte, traite et supprime vos données et vos fichiers.",
    body: `Dernière mise à jour : janvier 2026.

## Données collectées

Nous collectons uniquement les données nécessaires au fonctionnement du service : adresse e-mail et mot de passe chiffré lors de la création d'un compte, métadonnées de conversion (nom du fichier, taille, outil utilisé, date) et données techniques de sécurité.

## Traitement des fichiers

Les fichiers que vous envoyez sont traités sur nos serveurs pour produire le document demandé. Ils sont stockés temporairement puis **supprimés automatiquement** à l'expiration du délai de conservation, fixé par défaut à 2 heures. Vous pouvez supprimer manuellement un fichier depuis votre tableau de bord.

## Finalités

- Fournir le service de conversion demandé
- Gérer votre compte, votre quota et votre abonnement
- Assurer la sécurité et prévenir les abus
- Mesurer l'audience de façon agrégée

## Base légale

Exécution du contrat (fourniture du service), intérêt légitime (sécurité) et consentement (cookies de mesure et publicité personnalisée).

## Sous-traitants

Hébergement, service de paiement (Stripe) et régie publicitaire (Google AdSense) lorsqu'ils sont activés. Chaque prestataire est soumis à des obligations contractuelles de confidentialité.

## Vos droits

Vous disposez d'un droit d'accès, de rectification, d'effacement, de portabilité et d'opposition. Écrivez-nous depuis la page Contact pour exercer ces droits.

## Sécurité

Transport chiffré (HTTPS), mots de passe hachés, contrôle d'accès par rôle, validation stricte des fichiers envoyés et purge automatique du stockage temporaire.`,
  },
  conditions: {
    title: "Conditions d'utilisation",
    description: "Les règles d'utilisation de la plateforme DocuConvert.",
    body: `## Objet

Les présentes conditions régissent l'utilisation de la plateforme DocuConvert, qui propose des outils de conversion et d'organisation de documents en ligne.

## Compte utilisateur

La création d'un compte est gratuite. Vous êtes responsable de la confidentialité de vos identifiants et de l'usage fait de votre compte.

## Usage acceptable

Il est interdit d'envoyer des fichiers illicites, protégés par un droit dont vous ne disposez pas, ou contenant du code malveillant. Nous nous réservons le droit de suspendre un compte en cas d'abus ou de contournement des quotas.

## Disponibilité

Le service est fourni « en l'état ». Nous mettons tout en œuvre pour assurer sa disponibilité mais ne garantissons pas une absence totale d'interruption.

## Abonnements

Les offres payantes sont facturées mensuellement via Stripe et résiliables à tout moment. Le service reste actif jusqu'à la fin de la période en cours.

## Responsabilité

Vous restez seul responsable des documents que vous traitez. Conservez toujours une copie de vos fichiers originaux.`,
  },
  cookies: {
    title: "Politique relative aux cookies",
    description: "Quels cookies sont utilisés sur DocuConvert et comment les contrôler.",
    body: `## Cookies strictement nécessaires

Ils permettent l'authentification (cookie de session sécurisé, HttpOnly) et la sécurité du service. Ils ne peuvent pas être désactivés.

## Cookies de mesure d'audience

Déposés uniquement après votre consentement, ils nous aident à comprendre l'usage du site de manière agrégée.

## Cookies publicitaires

Lorsque Google AdSense est activé, des cookies publicitaires peuvent être déposés après consentement afin d'afficher des annonces pertinentes. Sans consentement, seules des annonces non personnalisées peuvent être servies.

## Gérer votre choix

La bannière affichée lors de votre première visite vous permet d'accepter ou de refuser les cookies non essentiels. Vous pouvez modifier votre choix à tout moment en effaçant les données du site dans votre navigateur.`,
  },
  "mentions-legales": {
    title: "Mentions légales",
    description: "Éditeur, hébergeur et informations légales de DocuConvert.",
    body: `## Éditeur

DocuConvert — plateforme en ligne de conversion de documents. Les informations d'immatriculation (raison sociale, SIREN, adresse, directeur de la publication) doivent être complétées avant la mise en production.

## Hébergement

Hébergement européen. Les coordonnées complètes de l'hébergeur doivent être renseignées avant la mise en ligne.

## Propriété intellectuelle

L'ensemble des éléments du site (marque, interface, textes, illustrations) est protégé. Toute reproduction non autorisée est interdite.

## Contact

Toute demande peut être adressée via la page Contact.`,
  },
  "a-propos": {
    title: "À propos de DocuConvert",
    description: "Notre mission : simplifier la gestion quotidienne des documents.",
    body: `## Notre mission

DocuConvert réunit en un seul endroit les outils dont vous avez besoin pour convertir, alléger et organiser vos documents. Pas d'installation, pas de logiciel lourd, pas de compte obligatoire pour essayer.

## Nos principes

- **Transparence** : nous n'annonçons jamais une conversion qui n'a pas réellement abouti.
- **Confidentialité** : vos fichiers sont supprimés automatiquement après traitement.
- **Simplicité** : une interface claire, pensée pour tous les niveaux.
- **Performance** : des pages rapides et un traitement serveur optimisé.

## L'équipe

Une petite équipe de passionnés de productivité et de logiciels bien faits, qui publie aussi des tutoriels gratuits sur YouTube.`,
  },
};

export default function LegalPage({ id }: { id: string }) {
  const page = LEGAL_CONTENT[id];
  if (!page) return null;
  const { html } = renderMarkdown(page.body);
  return (
    <div className="container-page py-14">
      <div className="mx-auto max-w-3xl">
        <h1 className="text-4xl font-extrabold tracking-tight text-ink-900">{page.title}</h1>
        <p className="mt-3 text-lg text-ink-500">{page.description}</p>
        <div className="prose-dc mt-8" dangerouslySetInnerHTML={{ __html: html }} />
      </div>
    </div>
  );
}
