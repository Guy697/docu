"use client";

import { useState } from "react";

export default function SubscribeButton({
  planKey,
  label,
  variant = "primary",
}: {
  planKey: string;
  label: string;
  variant?: "primary" | "violet";
}) {
  const [message, setMessage] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const start = async () => {
    setBusy(true);
    setMessage(null);
    const res = await fetch("/api/billing/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ plan: planKey }),
    });
    const data = await res.json().catch(() => ({}));
    setBusy(false);
    if (res.ok && data.url) {
      window.location.href = data.url;
      return;
    }
    setMessage(data.error ?? "Impossible de démarrer le paiement.");
  };

  return (
    <div>
      <button
        type="button"
        onClick={start}
        disabled={busy}
        className={variant === "violet" ? "btn-violet w-full" : "btn-primary w-full"}
      >
        {busy ? "Redirection…" : label}
      </button>
      {message && (
        <p className="mt-3 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
          {message}
        </p>
      )}
    </div>
  );
}
