import {
  pgTable,
  serial,
  text,
  varchar,
  timestamp,
  integer,
  boolean,
  jsonb,
  bigint,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  name: varchar("name", { length: 120 }).notNull().default(""),
  role: varchar("role", { length: 20 }).notNull().default("user"), // user | admin
  plan: varchar("plan", { length: 20 }).notNull().default("free"), // free | premium | business
  stripeCustomerId: varchar("stripe_customer_id", { length: 120 }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const conversions = pgTable("conversions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  tool: varchar("tool", { length: 60 }).notNull(),
  status: varchar("status", { length: 20 }).notNull().default("done"), // done | error
  inputName: text("input_name").notNull(),
  outputName: text("output_name"),
  inputSize: bigint("input_size", { mode: "number" }).notNull().default(0),
  outputSize: bigint("output_size", { mode: "number" }).notNull().default(0),
  storageKey: text("storage_key"),
  errorMessage: text("error_message"),
  expiresAt: timestamp("expires_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 200 }).notNull().unique(),
  title: text("title").notNull(),
  excerpt: text("excerpt").notNull().default(""),
  content: text("content").notNull().default(""),
  coverImage: text("cover_image"),
  category: varchar("category", { length: 120 }).notNull().default("guides-pratiques"),
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
  author: varchar("author", { length: 120 }).notNull().default("Équipe DocuConvert"),
  published: boolean("published").notNull().default(true),
  seoTitle: text("seo_title"),
  seoDescription: text("seo_description"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  name: varchar("name", { length: 160 }).notNull(),
  description: text("description").notNull().default(""),
});

export const tutorials = pgTable("tutorials", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 200 }).notNull().unique(),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  youtubeId: varchar("youtube_id", { length: 40 }).notNull(),
  category: varchar("category", { length: 120 }).notNull().default("tutoriels-gratuits"),
  published: boolean("published").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const plans = pgTable("plans", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 40 }).notNull().unique(), // free | premium | business
  name: varchar("name", { length: 80 }).notNull(),
  priceMonthly: integer("price_monthly").notNull().default(0), // cents
  currency: varchar("currency", { length: 8 }).notNull().default("EUR"),
  maxFileMb: integer("max_file_mb").notNull().default(10),
  dailyConversions: integer("daily_conversions").notNull().default(5),
  storageMb: integer("storage_mb").notNull().default(50),
  historyDays: integer("history_days").notNull().default(1),
  adsEnabled: boolean("ads_enabled").notNull().default(true),
  features: jsonb("features").$type<string[]>().notNull().default([]),
  stripePriceId: varchar("stripe_price_id", { length: 120 }),
  highlighted: boolean("highlighted").notNull().default(false),
  position: integer("position").notNull().default(0),
});

export const settings = pgTable("settings", {
  key: varchar("key", { length: 80 }).primaryKey(),
  value: jsonb("value").$type<Record<string, unknown>>().notNull().default({}),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type User = typeof users.$inferSelect;
export type Conversion = typeof conversions.$inferSelect;
export type Post = typeof posts.$inferSelect;
export type Tutorial = typeof tutorials.$inferSelect;
export type Plan = typeof plans.$inferSelect;
