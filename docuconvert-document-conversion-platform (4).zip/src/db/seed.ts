import { db } from "@/db";
import { users, plans, categories, posts, tutorials, settings } from "@/db/schema";
import { sql } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { DEFAULT_ADS, DEFAULT_SITE } from "@/lib/settings";

const SEED_KEY = "seed_version";
const SEED_VERSION = 3;

let seedPromise: Promise<void> | null = null;

export const BLOG_CATEGORIES = [
  { slug: "conversion-pdf", name: "Conversion PDF", description: "Tout sur la conversion et l'édition de fichiers PDF." },
  { slug: "word-bureautique", name: "Word et bureautique", description: "Astuces Word, Excel et suites bureautiques." },
  { slug: "astuces-productivite", name: "Astuces productivité", description: "Gagnez du temps au quotidien avec vos documents." },
  { slug: "tutoriels-gratuits", name: "Tutoriels gratuits", description: "Nos tutoriels vidéo pas à pas, 100 % gratuits." },
  { slug: "guides-pratiques", name: "Guides pratiques", description: "Guides complets pour maîtriser vos documents." },
  { slug: "outils-numeriques", name: "Outils numériques", description: "Comparatifs et sélections d'outils en ligne." },
  { slug: "offres-premium", name: "Offres Premium", description: "Nouveautés et avantages des offres DocuConvert." },
];

const POSTS = [
  {
    slug: "convertir-word-en-pdf-guide-complet",
    title: "Convertir Word en PDF : le guide complet 2026",
    category: "conversion-pdf",
    tags: ["word", "pdf", "conversion"],
    excerpt:
      "Pourquoi et comment transformer un document Word en PDF, quelles options choisir et comment éviter les pertes de mise en page.",
    content: `Le format PDF s'est imposé comme le standard d'échange de documents. Contrairement à un fichier Word, il s'affiche de la même façon sur tous les appareils et ne peut pas être modifié par inadvertance.

## Pourquoi convertir un Word en PDF ?

Un document .docx dépend des polices installées sur l'ordinateur qui l'ouvre. Résultat : la mise en page peut se décaler entre votre machine et celle de votre destinataire. Le PDF embarque la description complète de la page et supprime ce risque.

- Mise en page figée sur tous les appareils
- Fichier plus difficile à modifier accidentellement
- Format accepté par toutes les administrations
- Poids souvent inférieur au document d'origine

## Convertir en ligne en trois clics

Avec DocuConvert, ouvrez l'outil Word vers PDF, déposez votre fichier .docx puis lancez la conversion. Le document est traité sur nos serveurs puis supprimé automatiquement après la période de conservation.

## Vérifier le résultat

Ouvrez toujours le PDF généré avant de l'envoyer. Contrôlez la numérotation des pages, les titres et les listes. Si votre document contient des colonnes ou des images flottantes complexes, privilégiez un export depuis Word puis une compression avec notre outil dédié.

## Aller plus loin

Une fois votre PDF créé, vous pouvez le compresser, le fusionner avec d'autres documents ou en extraire certaines pages, le tout depuis votre navigateur.`,
  },
  {
    slug: "pdf-vers-word-conserver-mise-en-page",
    title: "PDF vers Word : comment récupérer un texte modifiable",
    category: "conversion-pdf",
    tags: ["pdf", "word", "ocr"],
    excerpt:
      "Extraire le texte d'un PDF pour le rééditer dans Word : méthodes, limites et solutions pour les documents scannés.",
    content: `Récupérer un contenu enfermé dans un PDF est une demande quotidienne. Voici comment procéder correctement.

## Deux types de PDF

Un PDF « natif » contient une couche de texte : le contenu est sélectionnable et peut être extrait fidèlement. Un PDF « scanné » n'est qu'une suite d'images : il faut une reconnaissance optique de caractères (OCR).

## La méthode en ligne

Chargez votre fichier dans l'outil PDF vers Word. DocuConvert analyse chaque page, reconstruit les lignes et génère un fichier .docx que vous pouvez éditer immédiatement.

## Limites à connaître

- Les colonnes multiples peuvent être linéarisées
- Les images ne sont pas réinsérées
- Les tableaux complexes deviennent du texte

## Bonnes pratiques

Relisez toujours le document obtenu, corrigez les sauts de ligne puis appliquez vos styles Word. Pour un usage régulier, l'offre Premium autorise des fichiers plus volumineux et un traitement prioritaire.`,
  },
  {
    slug: "compresser-pdf-sans-perdre-qualite",
    title: "Compresser un PDF sans perdre en qualité",
    category: "astuces-productivite",
    tags: ["compression", "pdf", "email"],
    excerpt:
      "Votre pièce jointe dépasse la limite de votre messagerie ? Voici comment alléger un PDF intelligemment.",
    content: `La plupart des messageries limitent les pièces jointes à 20 ou 25 Mo. Un rapport illustré dépasse vite cette limite.

## D'où vient le poids d'un PDF ?

Trois sources principales : les images haute résolution, les polices intégrées et les objets inutiles laissés par le logiciel d'origine.

## Optimisation sans perte

DocuConvert réécrit la structure interne du document, supprime les métadonnées superflues et active les flux compressés. Les pages et les images restent identiques. Le gain réel est toujours affiché après le traitement : nous n'annonçons jamais un résultat qui n'a pas eu lieu.

## Quand accepter une perte de qualité

Pour un envoi purement informatif, une réduction de la résolution des images à 150 dpi suffit largement. Pour l'impression, conservez 300 dpi.

## Astuce

Divisez les très gros documents en plusieurs fichiers avec l'outil Diviser un PDF plutôt que de tout compresser à l'extrême.`,
  },
  {
    slug: "fusionner-plusieurs-pdf-en-un-seul",
    title: "Fusionner plusieurs PDF en un seul document",
    category: "guides-pratiques",
    tags: ["fusion", "pdf", "organisation"],
    excerpt:
      "Regroupez devis, factures et annexes dans un dossier unique, propre et facile à envoyer.",
    content: `Envoyer dix pièces jointes séparées donne une mauvaise impression. Un document unique et ordonné est bien plus professionnel.

## Préparer les fichiers

Renommez vos documents avec un préfixe numérique (01-, 02-, 03-) afin de contrôler l'ordre de sélection.

## Fusionner en ligne

Ouvrez l'outil Fusionner PDF, ajoutez vos fichiers, vérifiez l'ordre affiché puis lancez l'assemblage. Les pages sont copiées sans recompression : la qualité d'origine est conservée.

## Après la fusion

Ajoutez une page de garde, réorganisez les pages ou supprimez celles en double grâce à nos outils complémentaires.`,
  },
  {
    slug: "10-astuces-word-gagner-du-temps",
    title: "10 astuces Word pour gagner du temps chaque jour",
    category: "word-bureautique",
    tags: ["word", "productivité", "astuces"],
    excerpt:
      "Styles, modèles, raccourcis clavier : dix réflexes simples pour rédiger deux fois plus vite.",
    content: `Word regorge de fonctions méconnues. En voici dix qui font gagner un temps considérable.

## 1. Utiliser les styles

Les styles ne servent pas qu'à l'esthétique : ils génèrent automatiquement la table des matières et facilitent la conversion en PDF.

## 2. Créer des modèles

Enregistrez vos documents récurrents comme modèles .dotx.

## 3. Maîtriser les raccourcis

Ctrl+Maj+C et Ctrl+Maj+V copient et collent la mise en forme seule.

## 4. Le volet navigation

Il permet de déplacer des chapitres entiers par glisser-déposer.

## 5. Les blocs de construction

Insérez vos paragraphes types en deux frappes.

## 6 à 10 : les réflexes d'expert

Vérificateur d'accessibilité, comparaison de versions, mode révision, champs automatiques et export PDF direct pour l'archivage.`,
  },
  {
    slug: "securite-documents-en-ligne",
    title: "Sécurité des documents en ligne : ce qu'il faut vérifier",
    category: "outils-numeriques",
    tags: ["sécurité", "confidentialité", "rgpd"],
    excerpt:
      "Avant de confier un contrat ou une fiche de paie à un outil en ligne, vérifiez ces cinq points essentiels.",
    content: `Tous les convertisseurs en ligne ne se valent pas. Voici la grille de lecture à appliquer.

## 1. Chiffrement du transport

Vérifiez la présence du HTTPS et d'un certificat valide.

## 2. Politique de conservation

Un service sérieux annonce une durée de rétention précise et supprime automatiquement les fichiers. Chez DocuConvert, les fichiers temporaires sont effacés après deux heures par défaut.

## 3. Localisation des données

Privilégiez un hébergement européen pour les documents contenant des données personnelles.

## 4. Transparence sur le traitement

Un outil honnête indique ce qu'il sait faire et ce qu'il ne sait pas faire, plutôt que de produire un fichier vide.

## 5. Contrôle du compte

Historique consultable, suppression manuelle des fichiers et export de vos données doivent être possibles.`,
  },
  {
    slug: "pourquoi-passer-premium-docuconvert",
    title: "Premium DocuConvert : à qui cela s'adresse-t-il ?",
    category: "offres-premium",
    tags: ["premium", "abonnement", "tarifs"],
    excerpt:
      "Plus de conversions, fichiers plus lourds, traitement prioritaire et zéro publicité : faisons le point.",
    content: `L'offre gratuite couvre les besoins ponctuels. Dès que la conversion devient un geste quotidien, Premium change la donne.

## Ce que change Premium

- Quota quotidien fortement augmenté
- Taille de fichier maximale supérieure
- File de traitement prioritaire
- Aucune publicité
- Historique de conversions étendu

## Et l'offre Business ?

Elle ajoute des limites très élevées, l'usage professionnel, le support prioritaire et la gestion multi-utilisateurs.

## Tarifs configurables

Les prix affichés sur la page Tarifs sont pilotés depuis l'espace administrateur et synchronisés avec Stripe lors de la mise en production.`,
  },
];

const TUTORIALS = [
  {
    slug: "convertir-word-en-pdf-en-1-minute",
    title: "Convertir un Word en PDF en 1 minute",
    description:
      "Tutoriel pas à pas pour transformer un document Word en PDF propre et prêt à envoyer, sans installer de logiciel.",
    youtubeId: "dQw4w9WgXcQ",
    category: "tutoriels-gratuits",
  },
  {
    slug: "fusionner-des-pdf-facilement",
    title: "Fusionner des PDF facilement",
    description: "Regroupez plusieurs documents PDF en un seul fichier ordonné en quelques clics.",
    youtubeId: "aqz-KE-bpKQ",
    category: "tutoriels-gratuits",
  },
  {
    slug: "compresser-un-pdf-trop-lourd",
    title: "Compresser un PDF trop lourd pour un e-mail",
    description: "Réduisez le poids de vos pièces jointes tout en gardant un document lisible.",
    youtubeId: "ScMzIvxBSi4",
    category: "astuces-productivite",
  },
  {
    slug: "organiser-les-pages-dun-pdf",
    title: "Organiser, pivoter et supprimer des pages d'un PDF",
    description: "Maîtrisez les outils d'organisation de pages pour livrer un document impeccable.",
    youtubeId: "hY7m5jjJ9mM",
    category: "guides-pratiques",
  },
];

async function seed() {
  const existing = await db
    .select()
    .from(settings)
    .where(sql`${settings.key} = ${SEED_KEY}`)
    .limit(1);
  const version = (existing[0]?.value as { version?: number } | undefined)?.version ?? 0;
  if (version >= SEED_VERSION) return;

  const adminHash = await bcrypt.hash("Admin1234!", 10);
  const demoHash = await bcrypt.hash("Demo1234!", 10);

  await db
    .insert(users)
    .values([
      { email: "admin@docuconvert.app", passwordHash: adminHash, name: "Administrateur", role: "admin", plan: "business" },
      { email: "demo@docuconvert.app", passwordHash: demoHash, name: "Utilisateur démo", role: "user", plan: "free" },
    ])
    .onConflictDoNothing();

  await db
    .insert(plans)
    .values([
      {
        key: "free",
        name: "Gratuit",
        priceMonthly: 0,
        maxFileMb: 10,
        dailyConversions: 5,
        storageMb: 50,
        historyDays: 1,
        adsEnabled: true,
        highlighted: false,
        position: 1,
        features: [
          "5 conversions par jour",
          "Fichiers jusqu'à 10 Mo",
          "Outils essentiels PDF et Word",
          "Publicités affichées",
          "Historique de 24 heures",
        ],
      },
      {
        key: "premium",
        name: "Premium",
        priceMonthly: 599,
        maxFileMb: 100,
        dailyConversions: 200,
        storageMb: 2000,
        historyDays: 30,
        adsEnabled: false,
        highlighted: true,
        position: 2,
        features: [
          "200 conversions par jour",
          "Fichiers jusqu'à 100 Mo",
          "Traitement prioritaire",
          "Aucune publicité",
          "Historique 30 jours",
          "Support par e-mail",
        ],
      },
      {
        key: "business",
        name: "Business",
        priceMonthly: 1999,
        maxFileMb: 500,
        dailyConversions: 2000,
        storageMb: 20000,
        historyDays: 365,
        adsEnabled: false,
        highlighted: false,
        position: 3,
        features: [
          "2 000 conversions par jour",
          "Fichiers jusqu'à 500 Mo",
          "Usage professionnel et commercial",
          "Support prioritaire",
          "Historique 12 mois",
          "Accès API (sur demande)",
        ],
      },
    ])
    .onConflictDoNothing();

  await db.insert(categories).values(BLOG_CATEGORIES).onConflictDoNothing();

  await db
    .insert(posts)
    .values(
      POSTS.map((p, i) => ({
        ...p,
        published: true,
        author: "Équipe DocuConvert",
        seoTitle: `${p.title} | DocuConvert`,
        seoDescription: p.excerpt,
        createdAt: new Date(Date.now() - i * 86400000 * 4),
        updatedAt: new Date(Date.now() - i * 86400000 * 4),
      })),
    )
    .onConflictDoNothing();

  await db.insert(tutorials).values(TUTORIALS).onConflictDoNothing();

  await db
    .insert(settings)
    .values([
      { key: "ads", value: DEFAULT_ADS as unknown as Record<string, unknown> },
      { key: "site", value: DEFAULT_SITE as unknown as Record<string, unknown> },
      { key: SEED_KEY, value: { version: SEED_VERSION } },
    ])
    .onConflictDoUpdate({
      target: settings.key,
      set: { value: sql`excluded.value` },
    });
}

export function ensureSeeded(): Promise<void> {
  if (!seedPromise) {
    seedPromise = seed().catch((error) => {
      console.error("[seed] échec:", error);
      seedPromise = null;
    });
  }
  return seedPromise;
}
