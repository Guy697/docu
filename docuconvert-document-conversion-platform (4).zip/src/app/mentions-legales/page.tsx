import type { Metadata } from "next";
import LegalPage, { LEGAL_CONTENT } from "@/components/LegalPage";

export const metadata: Metadata = {
  title: LEGAL_CONTENT["mentions-legales"].title,
  description: LEGAL_CONTENT["mentions-legales"].description,
  alternates: { canonical: "/mentions-legales" },
};

export default function Page() {
  return <LegalPage id="mentions-legales" />;
}
