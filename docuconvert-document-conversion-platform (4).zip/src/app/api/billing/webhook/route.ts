import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

export const runtime = "nodejs";

/** Vérification de signature Stripe (schéma v1, HMAC SHA-256). */
function verify(payload: string, header: string | null, secret: string) {
  if (!header) return false;
  const parts = Object.fromEntries(header.split(",").map((p) => p.split("=") as [string, string]));
  const timestamp = parts.t;
  const signature = parts.v1;
  if (!timestamp || !signature) return false;
  const expected = crypto
    .createHmac("sha256", secret)
    .update(`${timestamp}.${payload}`)
    .digest("hex");
  try {
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
  } catch {
    return false;
  }
}

export async function POST(request: NextRequest) {
  const secret = process.env.STRIPE_WEBHOOK_SECRET;
  const payload = await request.text();
  if (!secret) {
    return NextResponse.json(
      { error: "Webhook Stripe non configuré (STRIPE_WEBHOOK_SECRET manquant)." },
      { status: 501 },
    );
  }
  if (!verify(payload, request.headers.get("stripe-signature"), secret)) {
    return NextResponse.json({ error: "Signature invalide." }, { status: 400 });
  }

  const event = JSON.parse(payload);
  const object = event?.data?.object ?? {};

  if (event.type === "checkout.session.completed") {
    const userId = Number(object?.metadata?.userId);
    const plan = String(object?.metadata?.plan ?? "premium");
    if (userId) {
      await db
        .update(users)
        .set({ plan, stripeCustomerId: object.customer ?? null })
        .where(eq(users.id, userId));
    }
  }

  if (event.type === "customer.subscription.deleted" && object.customer) {
    await db.update(users).set({ plan: "free" }).where(eq(users.stripeCustomerId, object.customer));
  }

  return NextResponse.json({ received: true });
}
