import { NextRequest, NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { getPlanByKey } from "@/lib/settings";

export const runtime = "nodejs";

/**
 * Création d'une session Stripe Checkout (abonnement récurrent).
 * Aucune donnée n'est simulée : tant que STRIPE_SECRET_KEY et l'identifiant de prix
 * ne sont pas configurés, l'API renvoie une erreur explicite.
 */
export async function POST(request: NextRequest) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json({ error: "Vous devez être connecté." }, { status: 401 });
  }
  const body = await request.json().catch(() => ({}));
  const planKey = String(body?.plan ?? "");
  const plan = await getPlanByKey(planKey);
  if (!plan || plan.key === "free") {
    return NextResponse.json({ error: "Offre invalide." }, { status: 400 });
  }

  const secret = process.env.STRIPE_SECRET_KEY;
  if (!secret || !plan.stripePriceId) {
    return NextResponse.json(
      {
        error:
          "Le paiement n'est pas encore activé sur cet environnement. Configurez STRIPE_SECRET_KEY et l'identifiant de prix Stripe de l'offre depuis l'espace administrateur pour activer les abonnements.",
        code: "STRIPE_NOT_CONFIGURED",
      },
      { status: 501 },
    );
  }

  const origin = request.headers.get("origin") ?? process.env.NEXT_PUBLIC_SITE_URL ?? "";
  const params = new URLSearchParams();
  params.set("mode", "subscription");
  params.set("success_url", `${origin}/dashboard?checkout=success`);
  params.set("cancel_url", `${origin}/tarifs?checkout=cancel`);
  params.set("customer_email", user.email);
  params.set("line_items[0][price]", plan.stripePriceId);
  params.set("line_items[0][quantity]", "1");
  params.set("metadata[userId]", String(user.id));
  params.set("metadata[plan]", plan.key);

  const response = await fetch("https://api.stripe.com/v1/checkout/sessions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${secret}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: params,
  });
  const data = await response.json();
  if (!response.ok) {
    return NextResponse.json(
      { error: data?.error?.message ?? "Stripe a refusé la demande." },
      { status: 502 },
    );
  }
  return NextResponse.json({ url: data.url });
}
