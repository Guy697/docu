import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { conversions } from "@/db/schema";
import { and, eq, gte, isNull, lt, sql } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { getPlanByKey } from "@/lib/settings";
import { getTool } from "@/lib/tools";
import { saveOutput, purgeExpired, deleteOutput, RETENTION_HOURS } from "@/lib/storage";
import {
  ConvertError,
  compressPdf,
  imagesToPdf,
  mergePdf,
  organizePdf,
  pdfToImage,
  pdfToWord,
  removePages,
  rotatePdf,
  splitPdf,
  wordToPdf,
  type ConvertResult,
} from "@/lib/convert/engine";

export const runtime = "nodejs";
export const maxDuration = 60;

const ANON_DAILY_LIMIT = 3;

async function cleanup() {
  try {
    const expired = await db
      .select()
      .from(conversions)
      .where(and(lt(conversions.expiresAt, new Date()), sql`${conversions.storageKey} is not null`))
      .limit(200);
    for (const row of expired) {
      if (row.storageKey) await deleteOutput(row.storageKey);
      await db.update(conversions).set({ storageKey: null }).where(eq(conversions.id, row.id));
    }
    await purgeExpired();
  } catch {
    /* non bloquant */
  }
}

export async function POST(request: NextRequest) {
  let form: FormData;
  try {
    form = await request.formData();
  } catch {
    return NextResponse.json({ error: "Requête invalide." }, { status: 400 });
  }

  const toolSlug = String(form.get("tool") ?? "");
  const tool = getTool(toolSlug);
  if (!tool) {
    return NextResponse.json({ error: "Outil inconnu." }, { status: 404 });
  }

  const rawFiles = form.getAll("files").filter((f): f is File => f instanceof File && f.size > 0);
  if (!rawFiles.length) {
    return NextResponse.json({ error: "Aucun fichier reçu. Sélectionnez un document." }, { status: 400 });
  }
  if (!tool.multiple && rawFiles.length > 1) {
    return NextResponse.json(
      { error: "Cet outil n'accepte qu'un seul fichier à la fois." },
      { status: 400 },
    );
  }
  if (rawFiles.length > 20) {
    return NextResponse.json({ error: "20 fichiers maximum par opération." }, { status: 400 });
  }

  const user = await getCurrentUser();
  const plan = (await getPlanByKey(user?.plan ?? "free")) ?? {
    maxFileMb: 10,
    dailyConversions: 5,
  };
  const maxBytes = plan.maxFileMb * 1024 * 1024;

  const allowed = tool.accept.split(",").map((e) => e.trim().toLowerCase());
  for (const file of rawFiles) {
    const ext = "." + (file.name.split(".").pop() ?? "").toLowerCase();
    if (!allowed.includes(ext)) {
      return NextResponse.json(
        {
          error: `Le fichier « ${file.name} » n'est pas pris en charge par cet outil. Formats acceptés : ${allowed.join(", ")}.`,
        },
        { status: 400 },
      );
    }
    if (file.size > maxBytes) {
      return NextResponse.json(
        {
          error: `« ${file.name} » dépasse la limite de ${plan.maxFileMb} Mo de votre offre. Passez à une offre supérieure pour des fichiers plus volumineux.`,
          upgrade: true,
        },
        { status: 413 },
      );
    }
  }

  // Quota journalier
  const since = new Date(Date.now() - 86400000);
  try {
    const [{ count }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(conversions)
      .where(
        user
          ? and(eq(conversions.userId, user.id), gte(conversions.createdAt, since))
          : and(isNull(conversions.userId), gte(conversions.createdAt, since)),
      );
    const limit = user ? plan.dailyConversions : ANON_DAILY_LIMIT;
    if (count >= limit) {
      return NextResponse.json(
        {
          error: user
            ? `Quota quotidien atteint (${limit} conversions). Passez à une offre supérieure pour continuer.`
            : `Limite de ${ANON_DAILY_LIMIT} conversions atteinte pour les visiteurs non connectés. Créez un compte gratuit pour continuer.`,
          upgrade: true,
        },
        { status: 429 },
      );
    }
  } catch {
    /* si la table n'est pas disponible, on laisse passer */
  }

  const files = await Promise.all(
    rawFiles.map(async (f) => ({ buffer: Buffer.from(await f.arrayBuffer()), name: f.name })),
  );
  const inputName = files.map((f) => f.name).join(", ");
  const inputSize = files.reduce((acc, f) => acc + f.buffer.length, 0);
  const opt = (key: string) => {
    const value = form.get(key);
    return typeof value === "string" && value.trim() ? value.trim() : undefined;
  };

  try {
    let result: ConvertResult;
    switch (tool.slug) {
      case "word-to-pdf":
        result = await wordToPdf(files[0].buffer, files[0].name);
        break;
      case "pdf-to-word":
        result = await pdfToWord(files[0].buffer, files[0].name);
        break;
      case "jpg-to-pdf":
        result = await imagesToPdf(files, opt("pageSize") ?? "a4");
        break;
      case "merge-pdf":
        result = await mergePdf(files);
        break;
      case "split-pdf":
        result = await splitPdf(files[0].buffer, files[0].name, opt("pages"));
        break;
      case "compress-pdf":
        result = await compressPdf(files[0].buffer, files[0].name);
        break;
      case "rotate-pdf":
        result = await rotatePdf(files[0].buffer, files[0].name, opt("angle"), opt("pages"));
        break;
      case "organize-pdf":
        result = await organizePdf(files[0].buffer, files[0].name, opt("order"));
        break;
      case "remove-pages-pdf":
        result = await removePages(files[0].buffer, files[0].name, opt("pages"));
        break;
      case "pdf-to-jpg":
        result = await pdfToImage(files[0].buffer, files[0].name, opt("format") ?? "jpg");
        break;
      default:
        return NextResponse.json({ error: "Outil non implémenté." }, { status: 501 });
    }

    const key = await saveOutput(result.buffer, result.filename);
    const expiresAt = new Date(Date.now() + RETENTION_HOURS * 3600 * 1000);
    let id: number | null = null;
    try {
      const inserted = await db
        .insert(conversions)
        .values({
          userId: user?.id ?? null,
          tool: tool.slug,
          status: "done",
          inputName,
          outputName: result.filename,
          inputSize,
          outputSize: result.buffer.length,
          storageKey: key,
          expiresAt,
        })
        .returning({ id: conversions.id });
      id = inserted[0]?.id ?? null;
    } catch {
      /* historique indisponible */
    }

    void cleanup();

    return NextResponse.json({
      id,
      filename: result.filename,
      size: result.buffer.length,
      inputSize,
      mime: result.mime,
      note: result.note,
      downloadUrl: `/api/files/${encodeURIComponent(key)}`,
      expiresAt: expiresAt.toISOString(),
    });
  } catch (error) {
    const message =
      error instanceof ConvertError
        ? error.message
        : "Le traitement a échoué. Le fichier est peut-être corrompu ou dans un format inattendu. Aucun document n'a été produit.";
    const code = error instanceof ConvertError ? error.code : "INTERNAL_ERROR";
    if (!(error instanceof ConvertError)) console.error("[convert]", error);
    try {
      await db.insert(conversions).values({
        userId: user?.id ?? null,
        tool: tool.slug,
        status: "error",
        inputName,
        inputSize,
        errorMessage: message,
      });
    } catch {
      /* ignore */
    }
    return NextResponse.json({ error: message, code }, { status: code === "NEEDS_INTEGRATION" ? 501 : 422 });
  }
}
