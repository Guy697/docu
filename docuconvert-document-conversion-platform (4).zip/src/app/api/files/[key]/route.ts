import { NextRequest, NextResponse } from "next/server";
import { readOutput } from "@/lib/storage";

export const runtime = "nodejs";

const MIME: Record<string, string> = {
  pdf: "application/pdf",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  jpg: "image/jpeg",
  png: "image/png",
  zip: "application/zip",
};

export async function GET(_request: NextRequest, context: { params: Promise<{ key: string }> }) {
  const { key } = await context.params;
  const decoded = decodeURIComponent(key);
  const file = await readOutput(decoded);
  if (!file) {
    return NextResponse.json(
      { error: "Fichier introuvable ou expiré. Relancez la conversion." },
      { status: 404 },
    );
  }
  const name = decoded.split("__").slice(1).join("__") || "docuconvert";
  const ext = (name.split(".").pop() ?? "").toLowerCase();
  return new NextResponse(new Uint8Array(file), {
    headers: {
      "Content-Type": MIME[ext] ?? "application/octet-stream",
      "Content-Disposition": `attachment; filename="${name}"`,
      "Content-Length": String(file.length),
      "Cache-Control": "private, no-store",
    },
  });
}
