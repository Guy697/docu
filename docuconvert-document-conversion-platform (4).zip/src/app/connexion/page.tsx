import type { Metadata } from "next";
import AuthForm from "@/components/AuthForm";

export const metadata: Metadata = {
  title: "Connexion",
  description: "Connectez-vous à votre compte DocuConvert.",
  robots: { index: false, follow: true },
};

export default function LoginPage() {
  return (
    <div className="container-page py-16">
      <AuthForm mode="login" />
    </div>
  );
}
