import { db } from "@/db";
import { tutorials as tutorialsTable } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { saveTutorial, deleteTutorial } from "../actions";

export const dynamic = "force-dynamic";

export default async function AdminTutorials({
  searchParams,
}: {
  searchParams: Promise<{ edit?: string }>;
}) {
  const { edit } = await searchParams;
  const videos = await db.select().from(tutorialsTable).orderBy(desc(tutorialsTable.createdAt));
  const editing = edit
    ? (await db.select().from(tutorialsTable).where(eq(tutorialsTable.id, Number(edit))).limit(1))[0]
    : null;

  return (
    <div>
      <h1 className="text-2xl font-bold text-ink-900">Tutoriels YouTube</h1>
      <p className="mt-1 text-sm text-ink-500">
        Ajoutez une vidéo en collant simplement son URL YouTube. Les vidéos sont diffusées via le
        lecteur officiel, jamais hébergées sur nos serveurs.
      </p>

      <form action={saveTutorial} className="card mt-6 space-y-4 p-6">
        <input type="hidden" name="id" value={editing?.id ?? ""} />
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="title">Titre</label>
            <input id="title" name="title" required className="input" defaultValue={editing?.title ?? ""} />
          </div>
          <div>
            <label className="label" htmlFor="youtubeUrl">URL YouTube</label>
            <input
              id="youtubeUrl"
              name="youtubeUrl"
              required
              className="input"
              placeholder="https://www.youtube.com/watch?v=..."
              defaultValue={editing ? `https://www.youtube.com/watch?v=${editing.youtubeId}` : ""}
            />
          </div>
        </div>
        <div>
          <label className="label" htmlFor="description">Description</label>
          <textarea id="description" name="description" rows={3} className="input" defaultValue={editing?.description ?? ""} />
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="slug">Slug</label>
            <input id="slug" name="slug" className="input" defaultValue={editing?.slug ?? ""} />
          </div>
          <div>
            <label className="label" htmlFor="category">Catégorie</label>
            <input id="category" name="category" className="input" defaultValue={editing?.category ?? "tutoriels-gratuits"} />
          </div>
        </div>
        <label className="flex items-center gap-2 text-sm text-ink-700">
          <input type="checkbox" name="published" defaultChecked={editing ? editing.published : true} />
          Publier le tutoriel
        </label>
        <button type="submit" className="btn-primary">
          {editing ? "Enregistrer" : "Ajouter le tutoriel"}
        </button>
      </form>

      <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {videos.map((video) => (
          <div key={video.id} className="card overflow-hidden">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={`https://i.ytimg.com/vi/${video.youtubeId}/hqdefault.jpg`}
              alt={video.title}
              className="aspect-video w-full object-cover"
            />
            <div className="p-4">
              <p className="text-sm font-semibold text-ink-900">{video.title}</p>
              <p className="mt-1 text-xs text-ink-500">{video.published ? "Publié" : "Brouillon"}</p>
              <div className="mt-3 flex items-center gap-3 text-sm">
                <a href={`/admin/tutoriels?edit=${video.id}`} className="text-brand-600 hover:underline">Modifier</a>
                <form action={deleteTutorial}>
                  <input type="hidden" name="id" value={video.id} />
                  <button className="text-rose-600 hover:underline" type="submit">Supprimer</button>
                </form>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
