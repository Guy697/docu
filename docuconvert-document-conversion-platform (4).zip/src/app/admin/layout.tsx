import type { ReactNode } from "react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

const NAV = [
  { href: "/admin", label: "Vue d'ensemble" },
  { href: "/admin/articles", label: "Articles du blog" },
  { href: "/admin/tutoriels", label: "Tutoriels YouTube" },
  { href: "/admin/utilisateurs", label: "Utilisateurs" },
  { href: "/admin/conversions", label: "Conversions" },
  { href: "/admin/tarifs", label: "Offres & limites" },
  { href: "/admin/publicites", label: "Emplacements AdSense" },
  { href: "/admin/contenu", label: "Textes du site" },
];

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect("/connexion");
  if (user.role !== "admin") redirect("/dashboard");

  return (
    <div className="container-page py-10">
      <div className="grid gap-8 lg:grid-cols-[240px_1fr]">
        <aside>
          <p className="text-xs font-semibold uppercase tracking-widest text-ink-500">
            Espace administrateur
          </p>
          <nav className="mt-4 flex flex-col gap-1">
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="rounded-lg px-3 py-2 text-sm font-medium text-ink-700 hover:bg-white hover:text-brand-700"
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </aside>
        <div className="min-w-0">{children}</div>
      </div>
    </div>
  );
}
