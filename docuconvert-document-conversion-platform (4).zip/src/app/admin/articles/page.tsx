import { db } from "@/db";
import { posts as postsTable, categories as categoriesTable } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { savePost, deletePost, togglePost } from "../actions";

export const dynamic = "force-dynamic";

export default async function AdminPosts({
  searchParams,
}: {
  searchParams: Promise<{ edit?: string }>;
}) {
  const { edit } = await searchParams;
  const posts = await db.select().from(postsTable).orderBy(desc(postsTable.createdAt));
  const categories = await db.select().from(categoriesTable);
  const editing = edit ? (await db.select().from(postsTable).where(eq(postsTable.id, Number(edit))).limit(1))[0] : null;

  return (
    <div>
      <h1 className="text-2xl font-bold text-ink-900">Articles du blog</h1>
      <p className="mt-1 text-sm text-ink-500">Créez, modifiez, publiez ou dépubliez vos articles.</p>

      <form action={savePost} className="card mt-6 space-y-4 p-6">
        <input type="hidden" name="id" value={editing?.id ?? ""} />
        <h2 className="text-base font-semibold text-ink-900">
          {editing ? `Modifier « ${editing.title} »` : "Nouvel article"}
        </h2>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="title">Titre</label>
            <input id="title" name="title" required className="input" defaultValue={editing?.title ?? ""} />
          </div>
          <div>
            <label className="label" htmlFor="slug">Slug (URL)</label>
            <input id="slug" name="slug" className="input" defaultValue={editing?.slug ?? ""} placeholder="généré automatiquement" />
          </div>
        </div>
        <div>
          <label className="label" htmlFor="excerpt">Extrait</label>
          <input id="excerpt" name="excerpt" className="input" defaultValue={editing?.excerpt ?? ""} />
        </div>
        <div>
          <label className="label" htmlFor="content">Contenu (Markdown simplifié : ## titres, - listes, **gras**)</label>
          <textarea id="content" name="content" rows={12} className="input font-mono text-xs" defaultValue={editing?.content ?? ""} />
        </div>
        <div className="grid gap-4 sm:grid-cols-3">
          <div>
            <label className="label" htmlFor="category">Catégorie</label>
            <select id="category" name="category" className="input" defaultValue={editing?.category ?? "guides-pratiques"}>
              {categories.map((c) => (
                <option key={c.slug} value={c.slug}>{c.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label" htmlFor="tags">Tags (séparés par des virgules)</label>
            <input id="tags" name="tags" className="input" defaultValue={editing?.tags?.join(", ") ?? ""} />
          </div>
          <div>
            <label className="label" htmlFor="author">Auteur</label>
            <input id="author" name="author" className="input" defaultValue={editing?.author ?? "Équipe DocuConvert"} />
          </div>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="coverImage">Image de couverture (URL)</label>
            <input id="coverImage" name="coverImage" className="input" defaultValue={editing?.coverImage ?? ""} />
          </div>
          <div>
            <label className="label" htmlFor="seoTitle">Titre SEO</label>
            <input id="seoTitle" name="seoTitle" className="input" defaultValue={editing?.seoTitle ?? ""} />
          </div>
        </div>
        <div>
          <label className="label" htmlFor="seoDescription">Meta description</label>
          <input id="seoDescription" name="seoDescription" className="input" defaultValue={editing?.seoDescription ?? ""} />
        </div>
        <label className="flex items-center gap-2 text-sm text-ink-700">
          <input type="checkbox" name="published" defaultChecked={editing ? editing.published : true} />
          Publier l&apos;article
        </label>
        <button type="submit" className="btn-primary">
          {editing ? "Enregistrer les modifications" : "Créer l'article"}
        </button>
      </form>

      <div className="card mt-8 overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase tracking-wide text-ink-500">
            <tr>
              <th className="px-5 py-3">Titre</th>
              <th className="px-5 py-3">Catégorie</th>
              <th className="px-5 py-3">Statut</th>
              <th className="px-5 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {posts.map((post) => (
              <tr key={post.id}>
                <td className="px-5 py-3 text-ink-900">{post.title}</td>
                <td className="px-5 py-3 text-ink-500">{post.category}</td>
                <td className="px-5 py-3">
                  <span className={`badge ${post.published ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-ink-500"}`}>
                    {post.published ? "Publié" : "Brouillon"}
                  </span>
                </td>
                <td className="px-5 py-3">
                  <div className="flex items-center justify-end gap-3">
                    <a href={`/admin/articles?edit=${post.id}`} className="text-brand-600 hover:underline">Modifier</a>
                    <form action={togglePost}>
                      <input type="hidden" name="id" value={post.id} />
                      <input type="hidden" name="published" value={post.published ? "false" : "true"} />
                      <button className="text-ink-500 hover:underline" type="submit">
                        {post.published ? "Dépublier" : "Publier"}
                      </button>
                    </form>
                    <form action={deletePost}>
                      <input type="hidden" name="id" value={post.id} />
                      <button className="text-rose-600 hover:underline" type="submit">Supprimer</button>
                    </form>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
