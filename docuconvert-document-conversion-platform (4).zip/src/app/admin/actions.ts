"use server";

import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { posts, tutorials, users, plans, conversions } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { setSetting, DEFAULT_ADS } from "@/lib/settings";
import { slugify } from "@/lib/markdown";
import { deleteOutput } from "@/lib/storage";

async function assertAdmin() {
  const user = await getCurrentUser();
  if (!user || user.role !== "admin") throw new Error("Accès refusé");
  return user;
}

function str(form: FormData, key: string) {
  return String(form.get(key) ?? "").trim();
}

export async function savePost(formData: FormData) {
  await assertAdmin();
  const id = Number(formData.get("id") ?? 0);
  const title = str(formData, "title");
  const slug = str(formData, "slug") || slugify(title);
  const values = {
    title,
    slug,
    excerpt: str(formData, "excerpt"),
    content: str(formData, "content"),
    coverImage: str(formData, "coverImage") || null,
    category: str(formData, "category") || "guides-pratiques",
    tags: str(formData, "tags")
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean),
    author: str(formData, "author") || "Équipe DocuConvert",
    published: formData.get("published") === "on",
    seoTitle: str(formData, "seoTitle") || null,
    seoDescription: str(formData, "seoDescription") || null,
    updatedAt: new Date(),
  };
  if (id) {
    await db.update(posts).set(values).where(eq(posts.id, id));
  } else {
    await db.insert(posts).values(values);
  }
  revalidatePath("/admin/articles");
  revalidatePath("/blog");
}

export async function deletePost(formData: FormData) {
  await assertAdmin();
  const id = Number(formData.get("id"));
  if (id) await db.delete(posts).where(eq(posts.id, id));
  revalidatePath("/admin/articles");
  revalidatePath("/blog");
}

export async function togglePost(formData: FormData) {
  await assertAdmin();
  const id = Number(formData.get("id"));
  const published = formData.get("published") === "true";
  if (id) await db.update(posts).set({ published }).where(eq(posts.id, id));
  revalidatePath("/admin/articles");
  revalidatePath("/blog");
}

function youtubeId(input: string) {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([A-Za-z0-9_-]{6,})/,
    /^([A-Za-z0-9_-]{6,})$/,
  ];
  for (const pattern of patterns) {
    const match = input.match(pattern);
    if (match) return match[1];
  }
  return "";
}

export async function saveTutorial(formData: FormData) {
  await assertAdmin();
  const id = Number(formData.get("id") ?? 0);
  const title = str(formData, "title");
  const video = youtubeId(str(formData, "youtubeUrl"));
  if (!video) throw new Error("URL YouTube invalide");
  const values = {
    title,
    slug: str(formData, "slug") || slugify(title),
    description: str(formData, "description"),
    youtubeId: video,
    category: str(formData, "category") || "tutoriels-gratuits",
    published: formData.get("published") === "on",
  };
  if (id) {
    await db.update(tutorials).set(values).where(eq(tutorials.id, id));
  } else {
    await db.insert(tutorials).values(values);
  }
  revalidatePath("/admin/tutoriels");
  revalidatePath("/tutoriels");
}

export async function deleteTutorial(formData: FormData) {
  await assertAdmin();
  const id = Number(formData.get("id"));
  if (id) await db.delete(tutorials).where(eq(tutorials.id, id));
  revalidatePath("/admin/tutoriels");
  revalidatePath("/tutoriels");
}

export async function updateUser(formData: FormData) {
  await assertAdmin();
  const id = Number(formData.get("id"));
  if (!id) return;
  await db
    .update(users)
    .set({ plan: str(formData, "plan"), role: str(formData, "role") })
    .where(eq(users.id, id));
  revalidatePath("/admin/utilisateurs");
}

export async function savePlan(formData: FormData) {
  await assertAdmin();
  const id = Number(formData.get("id"));
  if (!id) return;
  await db
    .update(plans)
    .set({
      name: str(formData, "name"),
      priceMonthly: Math.round(Number(str(formData, "price") || "0") * 100),
      maxFileMb: Number(str(formData, "maxFileMb") || "10"),
      dailyConversions: Number(str(formData, "dailyConversions") || "5"),
      storageMb: Number(str(formData, "storageMb") || "50"),
      historyDays: Number(str(formData, "historyDays") || "1"),
      adsEnabled: formData.get("adsEnabled") === "on",
      stripePriceId: str(formData, "stripePriceId") || null,
      features: str(formData, "features")
        .split("\n")
        .map((f) => f.trim())
        .filter(Boolean),
    })
    .where(eq(plans.id, id));
  revalidatePath("/admin/tarifs");
  revalidatePath("/tarifs");
}

export async function saveAds(formData: FormData) {
  await assertAdmin();
  const slots: Record<string, boolean> = {};
  for (const key of Object.keys(DEFAULT_ADS.slots)) {
    slots[key] = formData.get(`slot_${key}`) === "on";
  }
  await setSetting("ads", {
    enabled: formData.get("enabled") === "on",
    clientId: str(formData, "clientId"),
    slots,
  });
  revalidatePath("/", "layout");
}

export async function saveSite(formData: FormData) {
  await assertAdmin();
  await setSetting("site", {
    siteName: str(formData, "siteName"),
    heroTitle: str(formData, "heroTitle"),
    heroSubtitle: str(formData, "heroSubtitle"),
    contactEmail: str(formData, "contactEmail"),
    retentionHours: Number(str(formData, "retentionHours") || "2"),
  });
  revalidatePath("/", "layout");
}

export async function deleteConversion(formData: FormData) {
  await assertAdmin();
  const id = Number(formData.get("id"));
  if (!id) return;
  const rows = await db.select().from(conversions).where(eq(conversions.id, id)).limit(1);
  if (rows[0]?.storageKey) await deleteOutput(rows[0].storageKey);
  await db.delete(conversions).where(eq(conversions.id, id));
  revalidatePath("/admin/conversions");
}
