import { getSiteConfig } from "@/lib/settings";
import { saveSite } from "../actions";

export const dynamic = "force-dynamic";

export default async function AdminContent() {
  const site = await getSiteConfig();

  return (
    <div>
      <h1 className="text-2xl font-bold text-ink-900">Textes du site</h1>
      <p className="mt-1 text-sm text-ink-500">
        Personnalisez les textes clés et la politique de conservation des fichiers.
      </p>

      <form action={saveSite} className="card mt-6 space-y-4 p-6">
        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="label" htmlFor="siteName">Nom du site</label>
            <input id="siteName" name="siteName" className="input" defaultValue={site.siteName} />
          </div>
          <div>
            <label className="label" htmlFor="contactEmail">E-mail de contact</label>
            <input id="contactEmail" name="contactEmail" className="input" defaultValue={site.contactEmail} />
          </div>
        </div>
        <div>
          <label className="label" htmlFor="heroTitle">Titre principal (accueil)</label>
          <input id="heroTitle" name="heroTitle" className="input" defaultValue={site.heroTitle} />
        </div>
        <div>
          <label className="label" htmlFor="heroSubtitle">Sous-titre (accueil)</label>
          <textarea id="heroSubtitle" name="heroSubtitle" rows={3} className="input" defaultValue={site.heroSubtitle} />
        </div>
        <div>
          <label className="label" htmlFor="retentionHours">Durée de conservation des fichiers (heures)</label>
          <input id="retentionHours" name="retentionHours" type="number" min={1} max={72} className="input max-w-[200px]" defaultValue={site.retentionHours} />
          <p className="mt-1 text-xs text-ink-500">
            Valeur appliquée au serveur via FILE_RETENTION_HOURS ; cette valeur sert de référence
            affichée aux utilisateurs.
          </p>
        </div>
        <button className="btn-primary" type="submit">Enregistrer</button>
      </form>
    </div>
  );
}
