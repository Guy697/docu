import { getAdsConfig, DEFAULT_ADS } from "@/lib/settings";
import { saveAds } from "../actions";

export const dynamic = "force-dynamic";

const LABELS: Record<string, string> = {
  homeTop: "Accueil — sous la section Hero",
  homeMiddle: "Accueil — entre outils et tutoriels",
  homeBottom: "Accueil — avant le footer",
  toolTop: "Page outil — au-dessus de la zone de conversion",
  toolResult: "Page outil — après le résultat",
  toolRelated: "Page outil — outils similaires",
  blogTop: "Blog — après le titre de l'article",
  blogMiddle: "Blog — milieu d'article",
  blogBottom: "Blog — fin d'article",
  blogSidebar: "Blog — sidebar desktop",
  tutorialUnderVideo: "Tutoriels — sous la vidéo",
  tutorialBeforeRelated: "Tutoriels — avant les recommandations",
};

export default async function AdminAds() {
  const config = await getAdsConfig();

  return (
    <div>
      <h1 className="text-2xl font-bold text-ink-900">Emplacements publicitaires</h1>
      <p className="mt-1 text-sm text-ink-500">
        Activez ou désactivez chaque emplacement. Sans identifiant AdSense, un cadre neutre est affiché
        (aucune fausse publicité n&apos;est jamais générée).
      </p>

      <form action={saveAds} className="card mt-6 space-y-5 p-6">
        <label className="flex items-center gap-2 text-sm font-medium text-ink-900">
          <input type="checkbox" name="enabled" defaultChecked={config.enabled} />
          Activer les emplacements publicitaires sur le site
        </label>

        <div>
          <label className="label" htmlFor="clientId">Identifiant client AdSense (ca-pub-…)</label>
          <input id="clientId" name="clientId" className="input max-w-md" defaultValue={config.clientId} placeholder="ca-pub-0000000000000000" />
          <p className="mt-1 text-xs text-ink-500">
            Renseignez également NEXT_PUBLIC_ADSENSE_CLIENT pour charger le script officiel AdSense.
          </p>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          {Object.keys(DEFAULT_ADS.slots).map((slot) => (
            <label key={slot} className="flex items-center gap-2 rounded-xl border border-slate-200 px-4 py-3 text-sm text-ink-700">
              <input type="checkbox" name={`slot_${slot}`} defaultChecked={config.slots?.[slot] !== false} />
              {LABELS[slot] ?? slot}
            </label>
          ))}
        </div>

        <button className="btn-primary" type="submit">Enregistrer la configuration</button>
      </form>

      <div className="card mt-6 p-6 text-sm text-ink-500">
        <h2 className="text-base font-semibold text-ink-900">Règles appliquées</h2>
        <ul className="mt-3 list-disc space-y-1.5 pl-5">
          <li>Aucune publicité dans la zone de dépôt de fichiers.</li>
          <li>Les publicités ne bloquent jamais le bouton de conversion ni le téléchargement.</li>
          <li>Formats responsives : 728×90, 336×280, 300×600 et 320×100.</li>
          <li>Fallback neutre lorsqu&apos;aucune annonce n&apos;est disponible.</li>
          <li>Consentement publicitaire recueilli via la bannière cookies.</li>
        </ul>
      </div>
    </div>
  );
}
