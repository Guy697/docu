import { db } from "@/db";
import { conversions as conversionsTable, users as usersTable } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { deleteConversion } from "../actions";
import { getTool } from "@/lib/tools";
import { formatBytes } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function AdminConversions() {
  const rows = await db
    .select({
      conversion: conversionsTable,
      email: usersTable.email,
    })
    .from(conversionsTable)
    .leftJoin(usersTable, eq(conversionsTable.userId, usersTable.id))
    .orderBy(desc(conversionsTable.createdAt))
    .limit(100);

  return (
    <div>
      <h1 className="text-2xl font-bold text-ink-900">Conversions</h1>
      <p className="mt-1 text-sm text-ink-500">
        100 dernières opérations. Les fichiers expirés sont automatiquement purgés du stockage.
      </p>

      <div className="card mt-6 overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase tracking-wide text-ink-500">
            <tr>
              <th className="px-5 py-3">Date</th>
              <th className="px-5 py-3">Utilisateur</th>
              <th className="px-5 py-3">Outil</th>
              <th className="px-5 py-3">Entrée → sortie</th>
              <th className="px-5 py-3">Statut</th>
              <th className="px-5 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rows.map(({ conversion, email }) => (
              <tr key={conversion.id}>
                <td className="whitespace-nowrap px-5 py-3 text-ink-500">
                  {new Date(conversion.createdAt).toLocaleString("fr-FR")}
                </td>
                <td className="px-5 py-3 text-ink-700">{email ?? "Visiteur"}</td>
                <td className="px-5 py-3 text-ink-700">{getTool(conversion.tool)?.name ?? conversion.tool}</td>
                <td className="px-5 py-3 text-ink-500">
                  {formatBytes(conversion.inputSize)} → {formatBytes(conversion.outputSize)}
                </td>
                <td className="px-5 py-3">
                  <span
                    className={`badge ${
                      conversion.status === "done" ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-700"
                    }`}
                    title={conversion.errorMessage ?? ""}
                  >
                    {conversion.status === "done" ? "Réussi" : "Échec"}
                  </span>
                </td>
                <td className="px-5 py-3 text-right">
                  <form action={deleteConversion}>
                    <input type="hidden" name="id" value={conversion.id} />
                    <button className="text-rose-600 hover:underline" type="submit">Supprimer</button>
                  </form>
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td colSpan={6} className="px-5 py-8 text-center text-ink-500">Aucune conversion.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
