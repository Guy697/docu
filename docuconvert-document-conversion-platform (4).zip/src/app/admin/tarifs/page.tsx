import { getPlans } from "@/lib/settings";
import { savePlan } from "../actions";

export const dynamic = "force-dynamic";

export default async function AdminPlans() {
  const plans = await getPlans();

  return (
    <div>
      <h1 className="text-2xl font-bold text-ink-900">Offres, limites et tarifs</h1>
      <p className="mt-1 text-sm text-ink-500">
        Les prix et limites définis ici s&apos;appliquent immédiatement sur le site et dans l&apos;API de
        conversion.
      </p>

      <div className="mt-6 space-y-6">
        {plans.map((plan) => (
          <form key={plan.id} action={savePlan} className="card space-y-4 p-6">
            <input type="hidden" name="id" value={plan.id} />
            <div className="flex items-center justify-between">
              <h2 className="text-base font-semibold text-ink-900">Offre « {plan.name} »</h2>
              <span className="badge bg-slate-100 text-ink-500">{plan.key}</span>
            </div>
            <div className="grid gap-4 sm:grid-cols-3">
              <div>
                <label className="label">Nom affiché</label>
                <input name="name" className="input" defaultValue={plan.name} />
              </div>
              <div>
                <label className="label">Prix mensuel ({plan.currency})</label>
                <input name="price" type="number" step="0.01" className="input" defaultValue={(plan.priceMonthly / 100).toFixed(2)} />
              </div>
              <div>
                <label className="label">Identifiant de prix Stripe</label>
                <input name="stripePriceId" className="input" placeholder="price_…" defaultValue={plan.stripePriceId ?? ""} />
              </div>
            </div>
            <div className="grid gap-4 sm:grid-cols-4">
              <div>
                <label className="label">Taille max. (Mo)</label>
                <input name="maxFileMb" type="number" className="input" defaultValue={plan.maxFileMb} />
              </div>
              <div>
                <label className="label">Conversions / jour</label>
                <input name="dailyConversions" type="number" className="input" defaultValue={plan.dailyConversions} />
              </div>
              <div>
                <label className="label">Stockage (Mo)</label>
                <input name="storageMb" type="number" className="input" defaultValue={plan.storageMb} />
              </div>
              <div>
                <label className="label">Historique (jours)</label>
                <input name="historyDays" type="number" className="input" defaultValue={plan.historyDays} />
              </div>
            </div>
            <div>
              <label className="label">Avantages (une ligne par avantage)</label>
              <textarea name="features" rows={5} className="input" defaultValue={plan.features.join("\n")} />
            </div>
            <label className="flex items-center gap-2 text-sm text-ink-700">
              <input type="checkbox" name="adsEnabled" defaultChecked={plan.adsEnabled} />
              Publicités affichées pour cette offre
            </label>
            <button className="btn-primary" type="submit">Enregistrer l&apos;offre</button>
          </form>
        ))}
      </div>
    </div>
  );
}
