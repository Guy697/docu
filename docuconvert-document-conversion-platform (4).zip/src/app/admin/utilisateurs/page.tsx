import { db } from "@/db";
import { users as usersTable } from "@/db/schema";
import { desc } from "drizzle-orm";
import { updateUser } from "../actions";

export const dynamic = "force-dynamic";

export default async function AdminUsers() {
  const users = await db.select().from(usersTable).orderBy(desc(usersTable.createdAt));

  return (
    <div>
      <h1 className="text-2xl font-bold text-ink-900">Utilisateurs</h1>
      <p className="mt-1 text-sm text-ink-500">Gérez les rôles et les offres des comptes.</p>

      <div className="card mt-6 overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 text-xs uppercase tracking-wide text-ink-500">
            <tr>
              <th className="px-5 py-3">E-mail</th>
              <th className="px-5 py-3">Nom</th>
              <th className="px-5 py-3">Inscription</th>
              <th className="px-5 py-3">Offre / rôle</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {users.map((user) => (
              <tr key={user.id}>
                <td className="px-5 py-3 text-ink-900">{user.email}</td>
                <td className="px-5 py-3 text-ink-500">{user.name}</td>
                <td className="px-5 py-3 text-ink-500">
                  {new Date(user.createdAt).toLocaleDateString("fr-FR")}
                </td>
                <td className="px-5 py-3">
                  <form action={updateUser} className="flex flex-wrap items-center gap-2">
                    <input type="hidden" name="id" value={user.id} />
                    <select name="plan" defaultValue={user.plan} className="input max-w-[140px] py-1.5 text-xs">
                      <option value="free">Gratuit</option>
                      <option value="premium">Premium</option>
                      <option value="business">Business</option>
                    </select>
                    <select name="role" defaultValue={user.role} className="input max-w-[120px] py-1.5 text-xs">
                      <option value="user">Utilisateur</option>
                      <option value="admin">Admin</option>
                    </select>
                    <button className="btn-secondary px-3 py-1.5 text-xs" type="submit">
                      Enregistrer
                    </button>
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
