import Link from "next/link";
import { db } from "@/db";
import { conversions, posts, tutorials, users } from "@/db/schema";
import { desc, sql } from "drizzle-orm";
import { getTool } from "@/lib/tools";
import { formatBytes } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function AdminHome() {
  const [[userCount], [conversionCount], [postCount], [tutorialCount]] = await Promise.all([
    db.select({ c: sql<number>`count(*)::int` }).from(users),
    db.select({ c: sql<number>`count(*)::int` }).from(conversions),
    db.select({ c: sql<number>`count(*)::int` }).from(posts),
    db.select({ c: sql<number>`count(*)::int` }).from(tutorials),
  ]);

  const byTool = await db
    .select({ tool: conversions.tool, c: sql<number>`count(*)::int` })
    .from(conversions)
    .groupBy(conversions.tool)
    .orderBy(desc(sql`count(*)`))
    .limit(6);

  const latest = await db
    .select()
    .from(conversions)
    .orderBy(desc(conversions.createdAt))
    .limit(8);

  const stats = [
    { label: "Utilisateurs", value: userCount.c, href: "/admin/utilisateurs" },
    { label: "Conversions", value: conversionCount.c, href: "/admin/conversions" },
    { label: "Articles", value: postCount.c, href: "/admin/articles" },
    { label: "Tutoriels", value: tutorialCount.c, href: "/admin/tutoriels" },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold text-ink-900">Vue d&apos;ensemble</h1>
      <p className="mt-1 text-sm text-ink-500">Statistiques générales de la plateforme.</p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Link key={stat.label} href={stat.href} className="card p-5 hover:border-brand-300">
            <p className="text-xs uppercase tracking-wide text-ink-500">{stat.label}</p>
            <p className="mt-2 text-2xl font-bold text-ink-900">{stat.value}</p>
          </Link>
        ))}
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <div className="card p-6">
          <h2 className="text-base font-semibold text-ink-900">Outils les plus utilisés</h2>
          <ul className="mt-4 space-y-3">
            {byTool.map((row) => (
              <li key={row.tool} className="flex items-center justify-between text-sm">
                <span className="text-ink-700">{getTool(row.tool)?.name ?? row.tool}</span>
                <span className="font-semibold text-ink-900">{row.c}</span>
              </li>
            ))}
            {byTool.length === 0 && <li className="text-sm text-ink-500">Aucune conversion enregistrée.</li>}
          </ul>
        </div>

        <div className="card p-6">
          <h2 className="text-base font-semibold text-ink-900">Dernières conversions</h2>
          <ul className="mt-4 space-y-3 text-sm">
            {latest.map((row) => (
              <li key={row.id} className="flex items-center justify-between gap-3">
                <span className="truncate text-ink-700">{row.inputName}</span>
                <span className="shrink-0 text-xs text-ink-500">
                  {formatBytes(row.inputSize)} · {row.status === "done" ? "OK" : "Échec"}
                </span>
              </li>
            ))}
            {latest.length === 0 && <li className="text-ink-500">Rien à afficher.</li>}
          </ul>
        </div>
      </div>
    </div>
  );
}
