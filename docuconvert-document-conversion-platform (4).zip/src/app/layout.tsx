import type { Metadata } from "next";
import type { ReactNode } from "react";
import Script from "next/script";
import "./globals.css";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import CookieBanner from "@/components/CookieBanner";
import { getCurrentUser } from "@/lib/auth";
import { ensureSeeded } from "@/db/seed";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "https://docuconvert.app"),
  title: {
    default: "DocuConvert — Tous vos outils PDF et Word en ligne",
    template: "%s | DocuConvert",
  },
  description:
    "Convertissez, compressez et organisez vos documents PDF et Word gratuitement en ligne. Rapide, sécurisé, sans installation.",
  keywords: [
    "convertir word en pdf",
    "pdf vers word",
    "fusionner pdf en ligne",
    "compresser pdf",
    "jpg en pdf",
    "outils pdf gratuits",
  ],
  openGraph: {
    type: "website",
    locale: "fr_FR",
    siteName: "DocuConvert",
    title: "DocuConvert — Tous vos outils PDF et Word en ligne",
    description:
      "Convertissez, compressez et organisez vos documents en quelques secondes, directement depuis votre navigateur.",
  },
  robots: { index: true, follow: true },
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  await ensureSeeded();
  const user = await getCurrentUser();
  const adsenseClient = process.env.NEXT_PUBLIC_ADSENSE_CLIENT;

  return (
    <html lang="fr">
      <body className="flex min-h-screen flex-col bg-slate-50 text-ink-900 antialiased">
        <Header user={user} />
        <main className="flex-1">{children}</main>
        <Footer />
        <CookieBanner />
        {adsenseClient && (
          <Script
            async
            strategy="afterInteractive"
            crossOrigin="anonymous"
            src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${adsenseClient}`}
          />
        )}
      </body>
    </html>
  );
}
