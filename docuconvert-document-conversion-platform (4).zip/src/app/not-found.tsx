import Link from "next/link";

export default function NotFound() {
  return (
    <div className="container-page flex flex-col items-center justify-center py-28 text-center">
      <span className="badge bg-brand-50 text-brand-700">Erreur 404</span>
      <h1 className="mt-4 text-4xl font-extrabold tracking-tight text-ink-900">Page introuvable</h1>
      <p className="mt-3 max-w-md text-ink-500">
        La page que vous cherchez n&apos;existe pas ou a été déplacée. Retrouvez tous nos outils depuis la
        page d&apos;accueil.
      </p>
      <div className="mt-8 flex gap-3">
        <Link href="/" className="btn-primary">Retour à l&apos;accueil</Link>
        <Link href="/outils" className="btn-secondary">Voir les outils</Link>
      </div>
    </div>
  );
}
