import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { TOOLS, getTool } from "@/lib/tools";
import ToolWorkspace from "@/components/ToolWorkspace";
import ToolCard from "@/components/ToolCard";
import { AdSlot } from "@/components/Ads";
import { Check } from "@/components/Icons";
import { getCurrentUser } from "@/lib/auth";
import { getPlanByKey } from "@/lib/settings";

export const dynamic = "force-dynamic";

export function generateStaticParams() {
  return TOOLS.map((t) => ({ tool: t.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ tool: string }>;
}): Promise<Metadata> {
  const { tool: slug } = await params;
  const tool = getTool(slug);
  if (!tool) return { title: "Page introuvable" };
  return {
    title: tool.seoTitle,
    description: tool.seoDescription,
    alternates: { canonical: `/${tool.slug}` },
    openGraph: { title: tool.seoTitle, description: tool.seoDescription, type: "website" },
  };
}

export default async function ToolPage({ params }: { params: Promise<{ tool: string }> }) {
  const { tool: slug } = await params;
  const tool = getTool(slug);
  if (!tool) notFound();

  const user = await getCurrentUser();
  const plan = await getPlanByKey(user?.plan ?? "free").catch(() => null);
  const maxFileMb = plan?.maxFileMb ?? 10;
  const related = tool.related.map((s) => getTool(s)).filter(Boolean);

  const faqJsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: tool.faq.map((item) => ({
      "@type": "Question",
      name: item.q,
      acceptedAnswer: { "@type": "Answer", text: item.a },
    })),
  };
  const howToJsonLd = {
    "@context": "https://schema.org",
    "@type": "HowTo",
    name: tool.h1,
    step: tool.steps.map((step, i) => ({ "@type": "HowToStep", position: i + 1, text: step })),
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify([faqJsonLd, howToJsonLd]) }}
      />

      <section className="border-b border-slate-200 bg-white">
        <div className="container-page py-10">
          <nav className="mb-5 flex items-center gap-2 text-xs text-ink-500">
            <Link href="/" className="hover:text-brand-600">Accueil</Link>
            <span>/</span>
            <Link href="/outils" className="hover:text-brand-600">Outils</Link>
            <span>/</span>
            <span className="text-ink-700">{tool.name}</span>
          </nav>
          <h1 className="max-w-3xl text-3xl font-extrabold tracking-tight text-ink-900 sm:text-4xl">
            {tool.h1}
          </h1>
          <p className="mt-4 max-w-2xl text-lg leading-relaxed text-ink-500">{tool.description}</p>
          <ul className="mt-6 flex flex-wrap gap-x-6 gap-y-2 text-sm text-ink-500">
            {["Gratuit et sans inscription", "Fichiers supprimés automatiquement", "Compatible mobile"].map(
              (item) => (
                <li key={item} className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-emerald-500" /> {item}
                </li>
              ),
            )}
          </ul>
        </div>
      </section>

      <div className="container-page pt-8">
        <AdSlot slot="toolTop" size="leaderboard" />
      </div>

      <section className="container-page py-8">
        <div className="card mx-auto max-w-4xl p-6 sm:p-8">
          <ToolWorkspace tools={[tool]} initialSlug={tool.slug} maxFileMb={maxFileMb} />
          <p className="mt-4 text-xs text-ink-500">
            Limite actuelle : {maxFileMb} Mo par fichier ({plan?.name ?? "offre gratuite"}).{" "}
            <Link href="/tarifs" className="font-medium text-brand-600 hover:underline">
              Augmenter la limite
            </Link>
          </p>
        </div>
      </section>

      <div className="container-page pb-6">
        <AdSlot slot="toolResult" size="rectangle" />
      </div>

      <section className="container-page grid gap-10 py-10 lg:grid-cols-2">
        <div className="card p-7">
          <h2 className="text-2xl font-bold text-ink-900">Comment utiliser cet outil ?</h2>
          <ol className="mt-6 space-y-4">
            {tool.steps.map((step, i) => (
              <li key={step} className="flex gap-4">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-brand-50 text-sm font-bold text-brand-600">
                  {i + 1}
                </span>
                <p className="text-sm leading-relaxed text-ink-700">{step}</p>
              </li>
            ))}
          </ol>
        </div>
        <div className="card p-7">
          <h2 className="text-2xl font-bold text-ink-900">Questions fréquentes</h2>
          <div className="mt-4 divide-y divide-slate-100">
            {tool.faq.map((item) => (
              <details key={item.q} className="group py-4">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-sm font-semibold text-ink-900">
                  {item.q}
                  <span className="text-brand-500 transition-transform group-open:rotate-45">+</span>
                </summary>
                <p className="mt-2 text-sm leading-relaxed text-ink-500">{item.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section className="container-page py-10">
        <h2 className="text-2xl font-bold text-ink-900">Outils similaires</h2>
        <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {related.map((item) => item && <ToolCard key={item.slug} tool={item} />)}
        </div>
        <div className="mt-8">
          <AdSlot slot="toolRelated" size="leaderboard" />
        </div>
      </section>
    </>
  );
}
