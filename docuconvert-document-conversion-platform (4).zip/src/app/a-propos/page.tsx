import type { Metadata } from "next";
import LegalPage, { LEGAL_CONTENT } from "@/components/LegalPage";

export const metadata: Metadata = {
  title: LEGAL_CONTENT["a-propos"].title,
  description: LEGAL_CONTENT["a-propos"].description,
  alternates: { canonical: "/a-propos" },
};

export default function Page() {
  return <LegalPage id="a-propos" />;
}
