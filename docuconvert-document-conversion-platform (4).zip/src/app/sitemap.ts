import type { MetadataRoute } from "next";
import { db } from "@/db";
import { posts as postsTable, tutorials as tutorialsTable, categories as categoriesTable } from "@/db/schema";
import { eq } from "drizzle-orm";
import { TOOLS } from "@/lib/tools";

export const dynamic = "force-dynamic";

const BASE = process.env.NEXT_PUBLIC_SITE_URL ?? "https://docuconvert.app";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const staticRoutes = [
    "",
    "/outils",
    "/outils/pdf",
    "/outils/word",
    "/outils/image",
    "/blog",
    "/tutoriels",
    "/tarifs",
    "/a-propos",
    "/contact",
    "/confidentialite",
    "/conditions",
    "/cookies",
    "/mentions-legales",
  ].map((path) => ({
    url: `${BASE}${path}`,
    lastModified: new Date(),
    changeFrequency: "weekly" as const,
    priority: path === "" ? 1 : 0.7,
  }));

  const toolRoutes = TOOLS.map((tool) => ({
    url: `${BASE}/${tool.slug}`,
    lastModified: new Date(),
    changeFrequency: "weekly" as const,
    priority: 0.9,
  }));

  const posts = await db
    .select()
    .from(postsTable)
    .where(eq(postsTable.published, true))
    .catch(() => []);
  const tutorials = await db
    .select()
    .from(tutorialsTable)
    .where(eq(tutorialsTable.published, true))
    .catch(() => []);
  const categories = await db.select().from(categoriesTable).catch(() => []);

  return [
    ...staticRoutes,
    ...toolRoutes,
    ...posts.map((post) => ({
      url: `${BASE}/blog/${post.slug}`,
      lastModified: new Date(post.updatedAt),
      priority: 0.6,
    })),
    ...tutorials.map((tutorial) => ({
      url: `${BASE}/tutoriels/${tutorial.slug}`,
      lastModified: new Date(tutorial.createdAt),
      priority: 0.6,
    })),
    ...categories.map((category) => ({
      url: `${BASE}/categories/${category.slug}`,
      lastModified: new Date(),
      priority: 0.5,
    })),
  ];
}
