import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { toolsByCategory, type ToolCategory } from "@/lib/tools";
import ToolCard from "@/components/ToolCard";
import { AdSlot } from "@/components/Ads";

const META: Record<string, { title: string; description: string; h1: string }> = {
  pdf: {
    title: "Outils PDF gratuits en ligne",
    description:
      "Fusionnez, divisez, compressez, pivotez et convertissez vos fichiers PDF gratuitement en ligne avec DocuConvert.",
    h1: "Outils PDF en ligne",
  },
  word: {
    title: "Outils Word en ligne",
    description:
      "Convertissez vos documents Word en PDF et récupérez un fichier Word modifiable depuis un PDF.",
    h1: "Outils Word en ligne",
  },
  image: {
    title: "Outils image et PDF",
    description: "Transformez vos images JPG, PNG et WEBP en PDF, ou exportez vos PDF en images.",
    h1: "Outils image",
  },
};

export function generateStaticParams() {
  return Object.keys(META).map((categorie) => ({ categorie }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ categorie: string }>;
}): Promise<Metadata> {
  const { categorie } = await params;
  const meta = META[categorie];
  if (!meta) return { title: "Catégorie introuvable" };
  return {
    title: meta.title,
    description: meta.description,
    alternates: { canonical: `/outils/${categorie}` },
  };
}

export default async function CategoryToolsPage({
  params,
}: {
  params: Promise<{ categorie: string }>;
}) {
  const { categorie } = await params;
  const meta = META[categorie];
  if (!meta) notFound();
  const tools = toolsByCategory(categorie as ToolCategory);

  return (
    <div className="container-page py-14">
      <h1 className="text-4xl font-extrabold tracking-tight text-ink-900">{meta.h1}</h1>
      <p className="mt-4 max-w-2xl text-lg text-ink-500">{meta.description}</p>
      <div className="mt-8">
        <AdSlot slot="toolTop" size="leaderboard" />
      </div>
      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {tools.map((tool) => (
          <ToolCard key={tool.slug} tool={tool} />
        ))}
      </div>
    </div>
  );
}
