import type { Metadata } from "next";
import Link from "next/link";
import { TOOLS } from "@/lib/tools";
import ToolCard from "@/components/ToolCard";
import { AdSlot } from "@/components/Ads";

export const metadata: Metadata = {
  title: "Tous les outils PDF et Word en ligne",
  description:
    "Découvrez tous les outils DocuConvert : conversion Word/PDF, images en PDF, fusion, division, compression, rotation et organisation de pages.",
  alternates: { canonical: "/outils" },
};

export default function ToolsPage() {
  return (
    <div className="container-page py-14">
      <h1 className="text-4xl font-extrabold tracking-tight text-ink-900">
        Tous les outils DocuConvert
      </h1>
      <p className="mt-4 max-w-2xl text-lg text-ink-500">
        Une boîte à outils complète pour vos documents : convertissez, assemblez, allégez et
        réorganisez vos fichiers en ligne, sans installer de logiciel.
      </p>

      <div className="mt-6 flex flex-wrap gap-2">
        <Link href="/outils/pdf" className="btn-secondary">Outils PDF</Link>
        <Link href="/outils/word" className="btn-secondary">Outils Word</Link>
        <Link href="/outils/image" className="btn-secondary">Outils Image</Link>
      </div>

      <div className="mt-8">
        <AdSlot slot="toolTop" size="leaderboard" />
      </div>

      <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {TOOLS.map((tool) => (
          <ToolCard key={tool.slug} tool={tool} />
        ))}
      </div>

      <div className="card mt-12 p-7">
        <h2 className="text-xl font-bold text-ink-900">D&apos;autres outils arrivent</h2>
        <p className="mt-2 max-w-2xl text-sm text-ink-500">
          Signature électronique, protection par mot de passe, OCR, Excel vers PDF, PowerPoint vers
          PDF : l&apos;architecture de DocuConvert est prête à accueillir de nouveaux outils. Écrivez-nous
          pour proposer le prochain.
        </p>
        <Link href="/contact" className="btn-primary mt-5">
          Proposer un outil
        </Link>
      </div>
    </div>
  );
}
