import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { getPlans, formatPrice } from "@/lib/settings";
import SubscribeButton from "@/components/SubscribeButton";
import { Check } from "@/components/Icons";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Mon abonnement",
  robots: { index: false, follow: false },
};

export default async function SubscriptionPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/connexion");
  const plans = await getPlans();

  return (
    <div className="container-page py-12">
      <Link href="/dashboard" className="text-sm text-brand-600 hover:underline">
        ← Retour au tableau de bord
      </Link>
      <h1 className="mt-4 text-3xl font-extrabold tracking-tight text-ink-900">Gérer mon abonnement</h1>
      <p className="mt-2 max-w-2xl text-ink-500">
        Votre offre actuelle est <strong className="text-ink-900">{user.plan}</strong>. Les paiements
        récurrents sont gérés par Stripe Checkout.
      </p>

      <div className="mt-10 grid gap-6 lg:grid-cols-3">
        {plans.map((plan) => {
          const current = plan.key === user.plan;
          return (
            <div key={plan.key} className={`card flex flex-col p-7 ${current ? "ring-2 ring-brand-500/30" : ""}`}>
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold text-ink-900">{plan.name}</h2>
                {current && <span className="badge bg-brand-50 text-brand-700">Offre actuelle</span>}
              </div>
              <p className="mt-3 text-3xl font-extrabold text-ink-900">
                {formatPrice(plan.priceMonthly, plan.currency)}
                <span className="ml-1 text-sm font-medium text-ink-500">
                  {plan.priceMonthly === 0 ? "€ / mois" : "/ mois"}
                </span>
              </p>
              <ul className="mt-5 flex-1 space-y-2 text-sm text-ink-700">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2">
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
                    {f}
                  </li>
                ))}
              </ul>
              <div className="mt-6">
                {plan.key === "free" || current ? (
                  <button className="btn-secondary w-full" disabled>
                    {current ? "Offre active" : "Offre de base"}
                  </button>
                ) : (
                  <SubscribeButton
                    planKey={plan.key}
                    label={`Passer à ${plan.name}`}
                    variant={plan.highlighted ? "primary" : "violet"}
                  />
                )}
              </div>
            </div>
          );
        })}
      </div>

      <div className="card mt-10 p-6">
        <h2 className="text-lg font-bold text-ink-900">Intégration Stripe</h2>
        <ul className="mt-3 space-y-2 text-sm text-ink-500">
          <li>1. Renseignez <code className="rounded bg-slate-100 px-1.5 py-0.5">STRIPE_SECRET_KEY</code> dans les variables d&apos;environnement.</li>
          <li>2. Créez un prix récurrent par offre dans Stripe et collez son identifiant depuis /admin/tarifs.</li>
          <li>3. Configurez le webhook <code className="rounded bg-slate-100 px-1.5 py-0.5">/api/billing/webhook</code> (événements checkout.session.completed et customer.subscription.deleted).</li>
        </ul>
      </div>
    </div>
  );
}
