import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { conversions } from "@/db/schema";
import { desc, eq, gte, and, sql } from "drizzle-orm";
import { getCurrentUser } from "@/lib/auth";
import { getPlanByKey, formatPrice } from "@/lib/settings";
import { formatBytes } from "@/lib/format";
import { getTool } from "@/lib/tools";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Tableau de bord",
  robots: { index: false, follow: false },
};

export default async function DashboardPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/connexion");

  const plan = await getPlanByKey(user.plan);
  const history = await db
    .select()
    .from(conversions)
    .where(eq(conversions.userId, user.id))
    .orderBy(desc(conversions.createdAt))
    .limit(30)
    .catch(() => []);

  const since = new Date(Date.now() - 86400000);
  const [today] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(conversions)
    .where(and(eq(conversions.userId, user.id), gte(conversions.createdAt, since)))
    .catch(() => [{ count: 0 }]);

  const storageUsed = history.reduce((acc, row) => acc + (row.storageKey ? row.outputSize : 0), 0);
  const storageQuota = (plan?.storageMb ?? 50) * 1024 * 1024;
  const storagePct = Math.min(100, Math.round((storageUsed / storageQuota) * 100));
  const dailyLimit = plan?.dailyConversions ?? 5;

  const stats = [
    { label: "Conversions totales", value: history.length },
    { label: "Conversions (24 h)", value: `${today?.count ?? 0} / ${dailyLimit}` },
    { label: "Offre actuelle", value: plan?.name ?? "Gratuit" },
    { label: "Stockage utilisé", value: formatBytes(storageUsed) },
  ];

  return (
    <div className="container-page py-12">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-ink-900">
            Bonjour {user.name || user.email}
          </h1>
          <p className="mt-2 text-ink-500">
            Suivez vos conversions, téléchargez vos fichiers récents et gérez votre abonnement.
          </p>
        </div>
        <div className="flex gap-2">
          <Link href="/outils" className="btn-secondary">Nouvelle conversion</Link>
          {user.plan === "free" && (
            <Link href="/dashboard/abonnement" className="btn-primary">Passer à Premium</Link>
          )}
        </div>
      </div>

      <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <div key={stat.label} className="card p-6">
            <p className="text-xs font-medium uppercase tracking-wide text-ink-500">{stat.label}</p>
            <p className="mt-2 text-2xl font-bold text-ink-900">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="card mt-6 p-6">
        <div className="flex items-center justify-between text-sm">
          <span className="font-medium text-ink-900">Espace de stockage</span>
          <span className="text-ink-500">
            {formatBytes(storageUsed)} / {plan?.storageMb ?? 50} Mo
          </span>
        </div>
        <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-slate-200">
          <div className="h-full rounded-full bg-brand-500" style={{ width: `${storagePct}%` }} />
        </div>
        <p className="mt-3 text-xs text-ink-500">
          Les fichiers générés sont supprimés automatiquement après la durée de conservation de votre
          offre ({plan?.historyDays ?? 1} jour(s) d&apos;historique).
        </p>
      </div>

      <section className="mt-10">
        <h2 className="text-xl font-bold text-ink-900">Historique des conversions</h2>
        <div className="card mt-4 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-xs uppercase tracking-wide text-ink-500">
                <tr>
                  <th className="px-5 py-3">Date</th>
                  <th className="px-5 py-3">Outil</th>
                  <th className="px-5 py-3">Fichier</th>
                  <th className="px-5 py-3">Taille</th>
                  <th className="px-5 py-3">Statut</th>
                  <th className="px-5 py-3"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {history.map((row) => (
                  <tr key={row.id}>
                    <td className="whitespace-nowrap px-5 py-3 text-ink-500">
                      {new Date(row.createdAt).toLocaleString("fr-FR")}
                    </td>
                    <td className="px-5 py-3 text-ink-700">{getTool(row.tool)?.name ?? row.tool}</td>
                    <td className="max-w-[220px] truncate px-5 py-3 text-ink-700">
                      {row.outputName ?? row.inputName}
                    </td>
                    <td className="whitespace-nowrap px-5 py-3 text-ink-500">
                      {formatBytes(row.outputSize || row.inputSize)}
                    </td>
                    <td className="px-5 py-3">
                      <span
                        className={`badge ${
                          row.status === "done" ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-700"
                        }`}
                      >
                        {row.status === "done" ? "Réussi" : "Échec"}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-right">
                      {row.storageKey ? (
                        <a
                          href={`/api/files/${encodeURIComponent(row.storageKey)}`}
                          className="font-medium text-brand-600 hover:underline"
                          download
                        >
                          Télécharger
                        </a>
                      ) : (
                        <span className="text-xs text-ink-500">Expiré</span>
                      )}
                    </td>
                  </tr>
                ))}
                {history.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-5 py-8 text-center text-ink-500">
                      Aucune conversion pour le moment.{" "}
                      <Link href="/outils" className="font-medium text-brand-600 hover:underline">
                        Convertir un premier fichier
                      </Link>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      {plan && (
        <section className="mt-10 card p-6">
          <h2 className="text-xl font-bold text-ink-900">Mon abonnement</h2>
          <p className="mt-2 text-sm text-ink-500">
            Offre {plan.name} — {formatPrice(plan.priceMonthly, plan.currency)}
            {plan.priceMonthly > 0 ? " / mois" : " €"} · {plan.maxFileMb} Mo par fichier ·{" "}
            {plan.dailyConversions} conversions par jour.
          </p>
          <Link href="/dashboard/abonnement" className="btn-secondary mt-4">
            Gérer mon abonnement
          </Link>
        </section>
      )}
    </div>
  );
}
