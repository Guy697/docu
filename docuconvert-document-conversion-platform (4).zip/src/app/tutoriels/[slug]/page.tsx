import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { tutorials as tutorialsTable } from "@/db/schema";
import { and, desc, eq, ne } from "drizzle-orm";
import { AdSlot } from "@/components/Ads";

export const dynamic = "force-dynamic";

async function getTutorial(slug: string) {
  const rows = await db
    .select()
    .from(tutorialsTable)
    .where(and(eq(tutorialsTable.slug, slug), eq(tutorialsTable.published, true)))
    .limit(1)
    .catch(() => []);
  return rows[0] ?? null;
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const tutorial = await getTutorial(slug);
  if (!tutorial) return { title: "Tutoriel introuvable" };
  return {
    title: tutorial.title,
    description: tutorial.description,
    alternates: { canonical: `/tutoriels/${tutorial.slug}` },
  };
}

export default async function TutorialPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const tutorial = await getTutorial(slug);
  if (!tutorial) notFound();

  const related = await db
    .select()
    .from(tutorialsTable)
    .where(and(eq(tutorialsTable.published, true), ne(tutorialsTable.id, tutorial.id)))
    .orderBy(desc(tutorialsTable.createdAt))
    .limit(3)
    .catch(() => []);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "VideoObject",
    name: tutorial.title,
    description: tutorial.description,
    thumbnailUrl: [`https://i.ytimg.com/vi/${tutorial.youtubeId}/hqdefault.jpg`],
    uploadDate: new Date(tutorial.createdAt).toISOString(),
    embedUrl: `https://www.youtube.com/embed/${tutorial.youtubeId}`,
  };

  return (
    <div className="container-page py-12">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <nav className="mb-5 flex items-center gap-2 text-xs text-ink-500">
        <Link href="/tutoriels" className="hover:text-brand-600">Tutoriels</Link>
        <span>/</span>
        <span className="text-ink-700">{tutorial.title}</span>
      </nav>

      <div className="grid gap-10 lg:grid-cols-[1fr_320px]">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight text-ink-900 sm:text-4xl">
            {tutorial.title}
          </h1>
          <p className="mt-3 text-lg text-ink-500">{tutorial.description}</p>

          <div className="mt-6 overflow-hidden rounded-2xl border border-slate-200 bg-black">
            <iframe
              className="aspect-video w-full"
              src={`https://www.youtube-nocookie.com/embed/${tutorial.youtubeId}`}
              title={tutorial.title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>

          <div className="mt-5 flex flex-wrap gap-3">
            <a
              className="btn-primary"
              target="_blank"
              rel="noopener noreferrer"
              href={`https://www.youtube.com/watch?v=${tutorial.youtubeId}`}
            >
              Regarder sur YouTube
            </a>
            <Link href="/outils" className="btn-secondary">
              Essayer les outils
            </Link>
          </div>

          <div className="mt-8">
            <AdSlot slot="tutorialUnderVideo" size="leaderboard" />
          </div>

          <section className="mt-12">
            <div className="mb-6">
              <AdSlot slot="tutorialBeforeRelated" size="rectangle" />
            </div>
            <h2 className="text-2xl font-bold text-ink-900">Tutoriels similaires</h2>
            <div className="mt-6 grid gap-5 sm:grid-cols-3">
              {related.map((item) => (
                <Link key={item.id} href={`/tutoriels/${item.slug}`} className="card overflow-hidden hover:border-brand-300">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={`https://i.ytimg.com/vi/${item.youtubeId}/hqdefault.jpg`}
                    alt={item.title}
                    className="aspect-video w-full object-cover"
                    loading="lazy"
                  />
                  <p className="p-4 text-sm font-semibold text-ink-900">{item.title}</p>
                </Link>
              ))}
            </div>
          </section>
        </div>

        <aside className="space-y-6">
          <div className="card p-6">
            <h2 className="text-sm font-semibold text-ink-900">Outils liés</h2>
            <ul className="mt-3 space-y-2 text-sm text-ink-500">
              <li><Link href="/word-to-pdf" className="hover:text-brand-600">Word vers PDF</Link></li>
              <li><Link href="/merge-pdf" className="hover:text-brand-600">Fusionner PDF</Link></li>
              <li><Link href="/compress-pdf" className="hover:text-brand-600">Compresser PDF</Link></li>
            </ul>
          </div>
          <AdSlot slot="blogSidebar" size="sidebar" className="hidden lg:block" />
        </aside>
      </div>
    </div>
  );
}
