import type { Metadata } from "next";
import Link from "next/link";
import { db } from "@/db";
import { tutorials as tutorialsTable } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { AdSlot } from "@/components/Ads";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Tutoriels vidéo gratuits PDF et Word",
  description:
    "Bibliothèque de tutoriels YouTube gratuits pour convertir, compresser et organiser vos documents PDF et Word.",
  alternates: { canonical: "/tutoriels" },
};

export default async function TutorialsPage() {
  const videos = await db
    .select()
    .from(tutorialsTable)
    .where(eq(tutorialsTable.published, true))
    .orderBy(desc(tutorialsTable.createdAt))
    .catch(() => []);

  return (
    <div className="container-page py-14">
      <header className="max-w-3xl">
        <h1 className="text-4xl font-extrabold tracking-tight text-ink-900">Tutoriels gratuits</h1>
        <p className="mt-4 text-lg text-ink-500">
          Des vidéos courtes et concrètes pour maîtriser vos documents. Toutes nos vidéos sont
          diffusées via le lecteur officiel YouTube.
        </p>
      </header>

      <div className="mt-8">
        <AdSlot slot="tutorialBeforeRelated" size="leaderboard" />
      </div>

      <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {videos.map((video) => (
          <article key={video.id} className="card overflow-hidden">
            <Link href={`/tutoriels/${video.slug}`}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={`https://i.ytimg.com/vi/${video.youtubeId}/hqdefault.jpg`}
                alt={video.title}
                className="aspect-video w-full object-cover"
                loading="lazy"
              />
            </Link>
            <div className="p-5">
              <h2 className="text-base font-semibold leading-snug text-ink-900">
                <Link href={`/tutoriels/${video.slug}`} className="hover:text-brand-600">
                  {video.title}
                </Link>
              </h2>
              <p className="mt-2 line-clamp-2 text-sm text-ink-500">{video.description}</p>
              <div className="mt-4 flex gap-2">
                <Link href={`/tutoriels/${video.slug}`} className="btn-secondary px-4 py-2">
                  Regarder le tutoriel
                </Link>
              </div>
            </div>
          </article>
        ))}
        {videos.length === 0 && <p className="text-ink-500">Aucun tutoriel publié pour le moment.</p>}
      </div>
    </div>
  );
}
