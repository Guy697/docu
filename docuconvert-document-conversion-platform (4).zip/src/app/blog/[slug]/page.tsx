import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { posts as postsTable, categories as categoriesTable } from "@/db/schema";
import { and, desc, eq, ne } from "drizzle-orm";
import { AdSlot } from "@/components/Ads";
import { readingTime, renderMarkdown } from "@/lib/markdown";

export const dynamic = "force-dynamic";

async function getPost(slug: string) {
  const rows = await db
    .select()
    .from(postsTable)
    .where(and(eq(postsTable.slug, slug), eq(postsTable.published, true)))
    .limit(1)
    .catch(() => []);
  return rows[0] ?? null;
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = await getPost(slug);
  if (!post) return { title: "Article introuvable" };
  return {
    title: post.seoTitle ?? post.title,
    description: post.seoDescription ?? post.excerpt,
    alternates: { canonical: `/blog/${post.slug}` },
    openGraph: {
      type: "article",
      title: post.title,
      description: post.excerpt,
      publishedTime: new Date(post.createdAt).toISOString(),
    },
  };
}

export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = await getPost(slug);
  if (!post) notFound();

  const { html, toc } = renderMarkdown(post.content);
  const halfway = html.indexOf("<h2", Math.floor(html.length / 2));
  const firstPart = halfway > 0 ? html.slice(0, halfway) : html;
  const secondPart = halfway > 0 ? html.slice(halfway) : "";

  const categories = await db.select().from(categoriesTable).catch(() => []);
  const category = categories.find((c) => c.slug === post.category);
  const related = await db
    .select()
    .from(postsTable)
    .where(and(eq(postsTable.published, true), ne(postsTable.id, post.id)))
    .orderBy(desc(postsTable.createdAt))
    .limit(3)
    .catch(() => []);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: post.title,
    description: post.excerpt,
    author: { "@type": "Organization", name: post.author },
    datePublished: new Date(post.createdAt).toISOString(),
    dateModified: new Date(post.updatedAt).toISOString(),
    publisher: { "@type": "Organization", name: "DocuConvert" },
  };

  const shareUrl = `https://docuconvert.app/blog/${post.slug}`;

  return (
    <div className="container-page py-12">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <nav className="mb-6 flex flex-wrap items-center gap-2 text-xs text-ink-500">
        <Link href="/" className="hover:text-brand-600">Accueil</Link>
        <span>/</span>
        <Link href="/blog" className="hover:text-brand-600">Blog</Link>
        {category && (
          <>
            <span>/</span>
            <Link href={`/categories/${category.slug}`} className="hover:text-brand-600">
              {category.name}
            </Link>
          </>
        )}
      </nav>

      <div className="grid gap-10 lg:grid-cols-[1fr_300px]">
        <article>
          <h1 className="text-4xl font-extrabold leading-tight tracking-tight text-ink-900">
            {post.title}
          </h1>
          <div className="mt-4 flex flex-wrap items-center gap-3 text-sm text-ink-500">
            <span className="font-medium text-ink-700">{post.author}</span>
            <span>·</span>
            <time dateTime={new Date(post.createdAt).toISOString()}>
              {new Date(post.createdAt).toLocaleDateString("fr-FR", {
                day: "numeric",
                month: "long",
                year: "numeric",
              })}
            </time>
            <span>·</span>
            <span>{readingTime(post.content)} min de lecture</span>
          </div>

          <div className="mt-6">
            <AdSlot slot="blogTop" size="leaderboard" />
          </div>

          {toc.length > 1 && (
            <nav className="card mt-8 p-6">
              <h2 className="text-sm font-semibold uppercase tracking-wide text-ink-500">
                Table des matières
              </h2>
              <ol className="mt-3 space-y-2 text-sm">
                {toc.map((item) => (
                  <li key={item.id} className={item.level === 3 ? "pl-4" : ""}>
                    <a href={`#${item.id}`} className="text-brand-600 hover:underline">
                      {item.text}
                    </a>
                  </li>
                ))}
              </ol>
            </nav>
          )}

          <div className="prose-dc mt-8 max-w-none" dangerouslySetInnerHTML={{ __html: firstPart }} />

          {secondPart && (
            <>
              <div className="my-8">
                <AdSlot slot="blogMiddle" size="rectangle" />
              </div>
              <div className="prose-dc max-w-none" dangerouslySetInnerHTML={{ __html: secondPart }} />
            </>
          )}

          {post.tags.length > 0 && (
            <div className="mt-8 flex flex-wrap gap-2">
              {post.tags.map((tag) => (
                <span key={tag} className="badge bg-slate-100 text-ink-700">
                  #{tag}
                </span>
              ))}
            </div>
          )}

          <div className="mt-8 flex flex-wrap items-center gap-3 border-t border-slate-200 pt-6">
            <span className="text-sm font-medium text-ink-700">Partager :</span>
            <a
              className="btn-secondary px-4 py-2"
              target="_blank"
              rel="noopener noreferrer"
              href={`https://x.com/intent/tweet?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(post.title)}`}
            >
              X
            </a>
            <a
              className="btn-secondary px-4 py-2"
              target="_blank"
              rel="noopener noreferrer"
              href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`}
            >
              LinkedIn
            </a>
            <a
              className="btn-secondary px-4 py-2"
              target="_blank"
              rel="noopener noreferrer"
              href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`}
            >
              Facebook
            </a>
          </div>

          <div className="mt-10">
            <AdSlot slot="blogBottom" size="leaderboard" />
          </div>

          <section className="mt-12">
            <h2 className="text-2xl font-bold text-ink-900">Articles recommandés</h2>
            <div className="mt-6 grid gap-5 sm:grid-cols-3">
              {related.map((item) => (
                <Link key={item.id} href={`/blog/${item.slug}`} className="card p-5 hover:border-brand-300">
                  <h3 className="text-sm font-semibold leading-snug text-ink-900">{item.title}</h3>
                  <p className="mt-2 line-clamp-3 text-xs text-ink-500">{item.excerpt}</p>
                </Link>
              ))}
            </div>
          </section>
        </article>

        <aside className="space-y-6">
          <AdSlot slot="blogSidebar" size="sidebar" className="hidden lg:block" />
          <div className="card p-6">
            <h2 className="text-sm font-semibold text-ink-900">Essayez nos outils</h2>
            <ul className="mt-3 space-y-2 text-sm text-ink-500">
              <li><Link href="/word-to-pdf" className="hover:text-brand-600">Word vers PDF</Link></li>
              <li><Link href="/pdf-to-word" className="hover:text-brand-600">PDF vers Word</Link></li>
              <li><Link href="/merge-pdf" className="hover:text-brand-600">Fusionner PDF</Link></li>
              <li><Link href="/compress-pdf" className="hover:text-brand-600">Compresser PDF</Link></li>
            </ul>
            <Link href="/tarifs" className="btn-primary mt-5 w-full">
              Voir les offres
            </Link>
          </div>
        </aside>
      </div>
    </div>
  );
}
