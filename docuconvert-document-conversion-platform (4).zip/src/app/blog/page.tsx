import type { Metadata } from "next";
import Link from "next/link";
import { db } from "@/db";
import { posts as postsTable, categories as categoriesTable } from "@/db/schema";
import { and, desc, eq, ilike, or } from "drizzle-orm";
import { AdSlot } from "@/components/Ads";
import { readingTime } from "@/lib/markdown";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Blog — conseils PDF, Word et productivité",
  description:
    "Guides pratiques, astuces bureautiques et tutoriels pour convertir, compresser et organiser vos documents.",
  alternates: { canonical: "/blog" },
};

export default async function BlogPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const { q } = await searchParams;
  const search = (q ?? "").trim();

  const where = search
    ? and(
        eq(postsTable.published, true),
        or(ilike(postsTable.title, `%${search}%`), ilike(postsTable.excerpt, `%${search}%`), ilike(postsTable.content, `%${search}%`)),
      )
    : eq(postsTable.published, true);

  const posts = await db.select().from(postsTable).where(where).orderBy(desc(postsTable.createdAt)).catch(() => []);
  const categories = await db.select().from(categoriesTable).catch(() => []);

  return (
    <div className="container-page py-14">
      <header className="max-w-3xl">
        <h1 className="text-4xl font-extrabold tracking-tight text-ink-900">Le blog DocuConvert</h1>
        <p className="mt-4 text-lg text-ink-500">
          Conseils pratiques, comparatifs d&apos;outils et tutoriels pour maîtriser vos documents au
          quotidien.
        </p>
      </header>

      <form className="mt-8 flex max-w-xl gap-2" action="/blog">
        <input
          className="input"
          type="search"
          name="q"
          defaultValue={search}
          placeholder="Rechercher un article (PDF, Word, compression…)"
          aria-label="Rechercher un article"
        />
        <button className="btn-primary" type="submit">
          Rechercher
        </button>
      </form>

      <div className="mt-6 flex flex-wrap gap-2">
        {categories.map((c) => (
          <Link
            key={c.slug}
            href={`/categories/${c.slug}`}
            className="badge border border-slate-200 bg-white text-ink-700 hover:border-brand-300 hover:text-brand-700"
          >
            {c.name}
          </Link>
        ))}
      </div>

      <div className="mt-10 grid gap-10 lg:grid-cols-[1fr_300px]">
        <div>
          {posts.length === 0 && (
            <p className="text-ink-500">Aucun article ne correspond à votre recherche.</p>
          )}
          <div className="grid gap-6 sm:grid-cols-2">
            {posts.map((post) => (
              <article key={post.id} className="card flex flex-col p-6">
                <span className="badge w-fit bg-brand-50 text-brand-700">
                  {categories.find((c) => c.slug === post.category)?.name ?? post.category}
                </span>
                <h2 className="mt-3 text-lg font-semibold leading-snug text-ink-900">
                  <Link href={`/blog/${post.slug}`} className="hover:text-brand-600">
                    {post.title}
                  </Link>
                </h2>
                <p className="mt-2 flex-1 text-sm leading-relaxed text-ink-500">{post.excerpt}</p>
                <div className="mt-4 flex items-center gap-3 text-xs text-ink-500">
                  <span>{new Date(post.createdAt).toLocaleDateString("fr-FR")}</span>
                  <span>·</span>
                  <span>{readingTime(post.content)} min de lecture</span>
                </div>
              </article>
            ))}
          </div>
        </div>

        <aside className="space-y-6">
          <AdSlot slot="blogSidebar" size="sidebar" className="hidden lg:block" />
          <div className="card p-6">
            <h2 className="text-sm font-semibold text-ink-900">Outils recommandés</h2>
            <ul className="mt-3 space-y-2 text-sm text-ink-500">
              <li><Link href="/word-to-pdf" className="hover:text-brand-600">Convertir Word en PDF</Link></li>
              <li><Link href="/pdf-to-word" className="hover:text-brand-600">Convertir PDF en Word</Link></li>
              <li><Link href="/compress-pdf" className="hover:text-brand-600">Compresser un PDF</Link></li>
              <li><Link href="/merge-pdf" className="hover:text-brand-600">Fusionner des PDF</Link></li>
            </ul>
          </div>
        </aside>
      </div>
    </div>
  );
}
