import type { Metadata } from "next";
import AuthForm from "@/components/AuthForm";

export const metadata: Metadata = {
  title: "Créer un compte gratuit",
  description: "Créez votre compte DocuConvert gratuitement et suivez votre historique de conversions.",
  robots: { index: false, follow: true },
};

export default function RegisterPage() {
  return (
    <div className="container-page py-16">
      <AuthForm mode="register" />
    </div>
  );
}
