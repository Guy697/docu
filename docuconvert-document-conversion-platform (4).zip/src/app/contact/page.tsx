import type { Metadata } from "next";
import Link from "next/link";
import { getSiteConfig } from "@/lib/settings";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Contact",
  description: "Une question, un bug, une suggestion d'outil ? Contactez l'équipe DocuConvert.",
  alternates: { canonical: "/contact" },
};

export default async function ContactPage() {
  const site = await getSiteConfig();
  return (
    <div className="container-page py-14">
      <div className="mx-auto max-w-2xl">
        <h1 className="text-4xl font-extrabold tracking-tight text-ink-900">Nous contacter</h1>
        <p className="mt-4 text-lg text-ink-500">
          Une question sur une conversion, un besoin professionnel ou une suggestion d&apos;outil ? Nous
          répondons sous 48 heures ouvrées.
        </p>

        <div className="card mt-8 p-7">
          <h2 className="text-base font-semibold text-ink-900">Par e-mail</h2>
          <a href={`mailto:${site.contactEmail}`} className="mt-1 block text-brand-600 hover:underline">
            {site.contactEmail}
          </a>

          <h2 className="mt-6 text-base font-semibold text-ink-900">Support Premium</h2>
          <p className="mt-1 text-sm text-ink-500">
            Les abonnés Premium et Business bénéficient d&apos;un traitement prioritaire de leurs demandes.
          </p>
          <Link href="/tarifs" className="btn-secondary mt-4">Voir les offres</Link>
        </div>

        <div className="card mt-6 p-7">
          <h2 className="text-base font-semibold text-ink-900">Questions fréquentes</h2>
          <ul className="mt-3 space-y-2 text-sm text-ink-500">
            <li>• Mes fichiers sont supprimés automatiquement après 2 heures.</li>
            <li>• Les conversions Word ↔ PDF sont opérationnelles sans configuration.</li>
            <li>• L&apos;export PDF vers images nécessite un moteur de rendu externe.</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
