import type { Metadata } from "next";
import LegalPage, { LEGAL_CONTENT } from "@/components/LegalPage";

export const metadata: Metadata = {
  title: LEGAL_CONTENT.cookies.title,
  description: LEGAL_CONTENT.cookies.description,
  alternates: { canonical: "/cookies" },
};

export default function Page() {
  return <LegalPage id="cookies" />;
}
