import type { Metadata } from "next";
import LegalPage, { LEGAL_CONTENT } from "@/components/LegalPage";

export const metadata: Metadata = {
  title: LEGAL_CONTENT.confidentialite.title,
  description: LEGAL_CONTENT.confidentialite.description,
  alternates: { canonical: "/confidentialite" },
};

export default function Page() {
  return <LegalPage id="confidentialite" />;
}
