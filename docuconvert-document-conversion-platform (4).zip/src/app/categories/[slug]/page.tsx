import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { posts as postsTable, categories as categoriesTable } from "@/db/schema";
import { and, desc, eq } from "drizzle-orm";
import { AdSlot } from "@/components/Ads";
import { readingTime } from "@/lib/markdown";

export const dynamic = "force-dynamic";

async function getCategory(slug: string) {
  const rows = await db
    .select()
    .from(categoriesTable)
    .where(eq(categoriesTable.slug, slug))
    .limit(1)
    .catch(() => []);
  return rows[0] ?? null;
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const category = await getCategory(slug);
  if (!category) return { title: "Catégorie introuvable" };
  return {
    title: `${category.name} — articles et guides`,
    description: category.description,
    alternates: { canonical: `/categories/${category.slug}` },
  };
}

export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const category = await getCategory(slug);
  if (!category) notFound();

  const posts = await db
    .select()
    .from(postsTable)
    .where(and(eq(postsTable.published, true), eq(postsTable.category, slug)))
    .orderBy(desc(postsTable.createdAt))
    .catch(() => []);

  return (
    <div className="container-page py-14">
      <nav className="mb-5 flex items-center gap-2 text-xs text-ink-500">
        <Link href="/blog" className="hover:text-brand-600">Blog</Link>
        <span>/</span>
        <span className="text-ink-700">{category.name}</span>
      </nav>
      <h1 className="text-4xl font-extrabold tracking-tight text-ink-900">{category.name}</h1>
      <p className="mt-3 max-w-2xl text-lg text-ink-500">{category.description}</p>

      <div className="mt-8">
        <AdSlot slot="blogTop" size="leaderboard" />
      </div>

      <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {posts.map((post) => (
          <article key={post.id} className="card flex flex-col p-6">
            <h2 className="text-lg font-semibold leading-snug text-ink-900">
              <Link href={`/blog/${post.slug}`} className="hover:text-brand-600">
                {post.title}
              </Link>
            </h2>
            <p className="mt-2 flex-1 text-sm text-ink-500">{post.excerpt}</p>
            <p className="mt-4 text-xs text-ink-500">
              {new Date(post.createdAt).toLocaleDateString("fr-FR")} · {readingTime(post.content)} min
            </p>
          </article>
        ))}
        {posts.length === 0 && <p className="text-ink-500">Aucun article dans cette catégorie pour le moment.</p>}
      </div>
    </div>
  );
}
