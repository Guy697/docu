import type { Metadata } from "next";
import LegalPage, { LEGAL_CONTENT } from "@/components/LegalPage";

export const metadata: Metadata = {
  title: LEGAL_CONTENT.conditions.title,
  description: LEGAL_CONTENT.conditions.description,
  alternates: { canonical: "/conditions" },
};

export default function Page() {
  return <LegalPage id="conditions" />;
}
