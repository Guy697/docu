import type { Metadata } from "next";
import Link from "next/link";
import { getPlans, formatPrice } from "@/lib/settings";
import { getCurrentUser } from "@/lib/auth";
import { Check } from "@/components/Icons";
import { AdSlot } from "@/components/Ads";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Tarifs — offres gratuite, Premium et Business",
  description:
    "Comparez les offres DocuConvert : gratuite, Premium et Business. Plus de conversions, fichiers plus lourds et traitement prioritaire.",
  alternates: { canonical: "/tarifs" },
};

const FAQ = [
  {
    q: "Puis-je changer d'offre à tout moment ?",
    a: "Oui. Le changement prend effet immédiatement et la facturation est ajustée au prorata lors de la mise en service de Stripe.",
  },
  {
    q: "Les prix affichés sont-ils définitifs ?",
    a: "Non : ils sont configurables depuis l'espace administrateur et seront synchronisés avec vos identifiants de prix Stripe avant la mise en production.",
  },
  {
    q: "Que se passe-t-il si je dépasse mon quota ?",
    a: "L'outil affiche un message clair et vous propose de passer à l'offre supérieure. Aucun fichier n'est traité silencieusement.",
  },
];

export default async function PricingPage() {
  const plans = await getPlans();
  const user = await getCurrentUser();

  return (
    <div className="container-page py-14">
      <header className="mx-auto max-w-3xl text-center">
        <span className="badge bg-brand-50 text-brand-700">Tarifs configurables</span>
        <h1 className="mt-4 text-4xl font-extrabold tracking-tight text-ink-900">
          Une offre pour chaque usage
        </h1>
        <p className="mt-4 text-lg text-ink-500">
          Commencez gratuitement, passez à Premium quand vos besoins augmentent. Les limites de chaque
          offre sont pilotées depuis l&apos;espace administrateur.
        </p>
      </header>

      <div className="mt-12 grid gap-6 lg:grid-cols-3">
        {plans.map((plan) => (
          <div
            key={plan.key}
            className={`card relative flex flex-col p-7 ${
              plan.highlighted ? "border-brand-300 ring-2 ring-brand-500/20" : ""
            }`}
          >
            {plan.highlighted && (
              <span className="badge absolute -top-3 left-7 bg-brand-600 text-white">
                Le plus populaire
              </span>
            )}
            <h2 className="text-lg font-bold text-ink-900">{plan.name}</h2>
            <p className="mt-4 flex items-end gap-1">
              <span className="text-4xl font-extrabold tracking-tight text-ink-900">
                {formatPrice(plan.priceMonthly, plan.currency)}
              </span>
              <span className="pb-1 text-sm text-ink-500">
                {plan.priceMonthly === 0 ? "€ / mois" : "/ mois"}
              </span>
            </p>
            <ul className="mt-6 flex-1 space-y-3 text-sm text-ink-700">
              {plan.features.map((feature) => (
                <li key={feature} className="flex items-start gap-2">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" />
                  {feature}
                </li>
              ))}
            </ul>
            <dl className="mt-6 space-y-1 border-t border-slate-100 pt-4 text-xs text-ink-500">
              <div className="flex justify-between"><dt>Taille max. par fichier</dt><dd>{plan.maxFileMb} Mo</dd></div>
              <div className="flex justify-between"><dt>Conversions / jour</dt><dd>{plan.dailyConversions}</dd></div>
              <div className="flex justify-between"><dt>Historique</dt><dd>{plan.historyDays} jour(s)</dd></div>
              <div className="flex justify-between"><dt>Publicités</dt><dd>{plan.adsEnabled ? "Oui" : "Non"}</dd></div>
            </dl>
            {plan.key === "free" ? (
              <Link href={user ? "/dashboard" : "/inscription"} className="btn-secondary mt-6">
                {user ? "Mon tableau de bord" : "Créer un compte gratuit"}
              </Link>
            ) : (
              <Link
                href={user ? `/dashboard/abonnement?plan=${plan.key}` : "/inscription"}
                className={plan.highlighted ? "btn-primary mt-6" : "btn-violet mt-6"}
              >
                Choisir {plan.name}
              </Link>
            )}
          </div>
        ))}
      </div>

      <p className="mt-6 text-center text-xs text-ink-500">
        Paiement récurrent géré par Stripe. L&apos;intégration est prête : renseignez STRIPE_SECRET_KEY,
        STRIPE_WEBHOOK_SECRET et l&apos;identifiant de prix de chaque offre pour activer le paiement réel.
      </p>

      <div className="mt-12">
        <AdSlot slot="homeBottom" size="leaderboard" />
      </div>

      <section className="mt-14 grid gap-6 lg:grid-cols-3">
        {FAQ.map((item) => (
          <div key={item.q} className="card p-6">
            <h3 className="text-sm font-semibold text-ink-900">{item.q}</h3>
            <p className="mt-2 text-sm text-ink-500">{item.a}</p>
          </div>
        ))}
      </section>
    </div>
  );
}
