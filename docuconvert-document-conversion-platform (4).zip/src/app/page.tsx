import Link from "next/link";
import Image from "next/image";
import { db } from "@/db";
import { tutorials as tutorialsTable } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { POPULAR_TOOLS, TOOLS } from "@/lib/tools";
import { getPlans, formatPrice } from "@/lib/settings";
import ToolWorkspace from "@/components/ToolWorkspace";
import ToolCard from "@/components/ToolCard";
import { AdSlot } from "@/components/Ads";
import { Check, Feature } from "@/components/Icons";

export const dynamic = "force-dynamic";

const ADVANTAGES = [
  {
    icon: "bolt",
    title: "Conversion rapide",
    text: "Le traitement démarre dès l'envoi du fichier. La plupart des documents sont prêts en moins de dix secondes.",
  },
  {
    icon: "sparkle",
    title: "Interface simple",
    text: "Une zone de dépôt, un bouton, un résultat. Aucun logiciel à installer, aucun compte obligatoire pour essayer.",
  },
  {
    icon: "layers",
    title: "Plusieurs formats",
    text: "Word, PDF, JPG, PNG, WEBP : les formats du quotidien sont pris en charge et de nouveaux outils arrivent.",
  },
  {
    icon: "devices",
    title: "Depuis tout appareil",
    text: "Ordinateur, tablette ou smartphone : l'interface s'adapte et le traitement se fait côté serveur.",
  },
];

export default async function HomePage() {
  const videos = await db
    .select()
    .from(tutorialsTable)
    .where(eq(tutorialsTable.published, true))
    .orderBy(desc(tutorialsTable.createdAt))
    .limit(3)
    .catch(() => []);
  const plans = await getPlans();
  const premium = plans.find((p) => p.key === "premium");

  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden border-b border-slate-200 bg-white">
        <div className="pointer-events-none absolute -right-32 -top-32 h-[420px] w-[420px] rounded-full bg-brand-100/60 blur-3xl" />
        <div className="pointer-events-none absolute -left-24 top-32 h-72 w-72 rounded-full bg-violet-100/60 blur-3xl" />
        <div className="container-page relative grid gap-12 py-16 lg:grid-cols-2 lg:items-center lg:py-24">
          <div>
            <span className="badge bg-brand-50 text-brand-700">
              <Check className="h-3.5 w-3.5" /> 100 % en ligne · sans installation
            </span>
            <h1 className="mt-5 text-4xl font-extrabold leading-[1.1] tracking-tight text-ink-900 sm:text-5xl">
              Tous vos outils PDF et Word, <span className="text-brand-600">au même endroit</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg leading-relaxed text-ink-500">
              Convertissez, compressez et organisez vos documents en quelques secondes. Des outils
              simples, rapides et accessibles directement en ligne.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a href="#convertir" className="btn-primary px-6 py-3 text-base">
                Convertir un fichier
              </a>
              <Link href="/outils" className="btn-secondary px-6 py-3 text-base">
                Découvrir les outils
              </Link>
            </div>
            <dl className="mt-10 grid max-w-md grid-cols-3 gap-6">
              {[
                ["10", "outils disponibles"],
                ["2 h", "de conservation max."],
                ["0 €", "pour démarrer"],
              ].map(([value, label]) => (
                <div key={label}>
                  <dt className="text-2xl font-bold text-ink-900">{value}</dt>
                  <dd className="text-xs text-ink-500">{label}</dd>
                </div>
              ))}
            </dl>
          </div>
          <div className="relative">
            <div className="card overflow-hidden p-4">
              <Image
                src="/images/hero-conversion.png"
                alt="Illustration d'un document Word converti en PDF"
                width={900}
                height={700}
                priority
                className="h-auto w-full rounded-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CONVERSION RAPIDE */}
      <section id="convertir" className="container-page -mt-6 scroll-mt-24 pb-4 pt-12">
        <div className="card mx-auto max-w-4xl p-6 sm:p-8">
          <h2 className="text-xl font-bold text-ink-900">Conversion rapide</h2>
          <p className="mt-1 text-sm text-ink-500">
            Choisissez un type de conversion, déposez votre fichier et lancez le traitement.
          </p>
          <div className="mt-6">
            <ToolWorkspace tools={TOOLS} initialSlug="word-to-pdf" allowSwitch maxFileMb={10} />
          </div>
        </div>
      </section>

      <div className="container-page py-8">
        <AdSlot slot="homeTop" size="leaderboard" />
      </div>

      {/* OUTILS POPULAIRES */}
      <section className="container-page py-12">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-ink-900">Outils populaires</h2>
            <p className="mt-2 text-ink-500">Les conversions les plus demandées par nos utilisateurs.</p>
          </div>
          <Link href="/outils" className="btn-secondary">
            Tous les outils
          </Link>
        </div>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {POPULAR_TOOLS.map((tool) => (
            <ToolCard key={tool.slug} tool={tool} />
          ))}
        </div>
      </section>

      {/* POURQUOI */}
      <section className="border-y border-slate-200 bg-white py-16">
        <div className="container-page">
          <h2 className="text-center text-3xl font-bold tracking-tight text-ink-900">
            Pourquoi choisir DocuConvert ?
          </h2>
          <p className="mx-auto mt-3 max-w-2xl text-center text-ink-500">
            Une plateforme pensée pour la simplicité, la rapidité et la confidentialité de vos documents.
          </p>
          <div className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {ADVANTAGES.map((item) => (
              <div key={item.title}>
                <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-brand-50 text-brand-600">
                  <Feature name={item.icon} />
                </span>
                <h3 className="mt-4 text-base font-semibold text-ink-900">{item.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-ink-500">{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="container-page py-10">
        <AdSlot slot="homeMiddle" size="leaderboard" />
      </div>

      {/* TUTORIELS */}
      <section className="container-page py-12">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-ink-900">Tutoriels gratuits</h2>
            <p className="mt-2 text-ink-500">Apprenez à maîtriser vos documents en quelques minutes.</p>
          </div>
          <Link href="/tutoriels" className="btn-secondary">
            Voir tous les tutoriels
          </Link>
        </div>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {videos.map((video) => (
            <article key={video.id} className="card overflow-hidden">
              <Link href={`/tutoriels/${video.slug}`} className="block">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={`https://i.ytimg.com/vi/${video.youtubeId}/hqdefault.jpg`}
                  alt={video.title}
                  className="aspect-video w-full object-cover"
                  loading="lazy"
                />
              </Link>
              <div className="p-5">
                <h3 className="text-base font-semibold text-ink-900">{video.title}</h3>
                <p className="mt-2 line-clamp-2 text-sm text-ink-500">{video.description}</p>
                <Link href={`/tutoriels/${video.slug}`} className="btn-secondary mt-4 px-4 py-2">
                  Regarder le tutoriel
                </Link>
              </div>
            </article>
          ))}
          {videos.length === 0 && (
            <p className="text-sm text-ink-500">Les tutoriels seront bientôt disponibles.</p>
          )}
        </div>
      </section>

      {/* PREMIUM */}
      <section className="container-page py-12">
        <div className="overflow-hidden rounded-3xl bg-gradient-to-br from-brand-700 via-brand-600 to-violet-700 px-8 py-14 text-white sm:px-14">
          <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
            <div>
              <h2 className="text-3xl font-bold tracking-tight">Passez à la vitesse supérieure</h2>
              <p className="mt-4 max-w-lg text-brand-50/90">
                Les offres Premium et Business lèvent les limites : fichiers plus lourds, traitement
                prioritaire, aucune publicité et historique complet de vos conversions.
              </p>
              <Link href="/tarifs" className="btn mt-8 bg-white px-6 py-3 text-base text-brand-700 hover:bg-brand-50">
                Découvrir les tarifs
              </Link>
            </div>
            <ul className="grid gap-3 sm:grid-cols-2">
              {(premium?.features ?? [
                "Plus de conversions",
                "Fichiers volumineux",
                "Traitement prioritaire",
                "Sans publicité",
              ]).map((feature) => (
                <li key={feature} className="flex items-start gap-2 text-sm text-brand-50">
                  <Check className="mt-0.5 h-4 w-4 shrink-0" />
                  {feature}
                </li>
              ))}
            </ul>
          </div>
          {premium && (
            <p className="mt-8 text-sm text-brand-100/80">
              À partir de {formatPrice(premium.priceMonthly, premium.currency)} / mois — tarifs
              configurables depuis l&apos;espace administrateur.
            </p>
          )}
        </div>
      </section>

      <div className="container-page pb-12">
        <AdSlot slot="homeBottom" size="leaderboard" />
      </div>
    </>
  );
}
